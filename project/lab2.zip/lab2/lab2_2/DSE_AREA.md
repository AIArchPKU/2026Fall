﻿# Design Space Exploration：面积测试入口

每个候选配置都应先通过全部十个公开功能测试（`ALL TEST CASES PASSED (10/10)`），再使用 [dse/dse.py](dse/dse.py) 取得标准单元面积和时序报告。只有功能全部通过且满足统一 10 ns 时序目标的配置，才纳入周期数与面积的帕累托比较。该入口不会自动执行功能测试。

不要求穷举所有数据流、优化方向或参数组合；挑选几个感兴趣的方案或配置进行比较，并分析面积与平均周期数的取舍即可。

## 1. 运行方式

Bash 终端中进入 `lab2_2`，执行：

```sh
source /etc/profile.d/eda.sh
python3 dse/dse.py run --name baseline
```

首次运行会自动准备 `build/dse/lib/aiarch_lab2_2.lib`；后续运行直接复用经过校验的副本。也可以在综合前单独准备库：

```sh
python3 dse/dse.py prepare-lib
```

也可以使用 `make dse` 或 `make dse-lib`，分别调用综合和库准备。

每次综合都写入 `build/dse/runs/` 下以配置名、时间及唯一标识组成的新目录，保留之前的结果。控制台会显示本次结果目录。该入口只进行综合，所以需要先用 README 中的 `make vcs` 或 `make xrun` 确认对应实现通过测试。

（初始 `conv_accel.v` 是常量输出的空模板，综合后可能为 0 个单元、0 面积。入口会将其标记为 `empty_design` 并返回失败）

## 2. 指定硬件源文件和架构参数

[dse/rtl.f](dse/rtl.f) 是独立的综合文件清单，每行一个相对 `lab2_2` 的 RTL 路径。默认只列 `src/conv_accel.v`；新增 PE、缓存等辅助模块时，将路径加入清单。例如：

```text
src/conv_accel.v
src/pe.v
src/buffer.v
```

不要把 testbench 加入综合清单。现有 `run/conv.f` 包含 testbench，不能直接用于这里。头文件也可列在清单中，入口只把它们记录为依赖，不将其作为独立模块读取；默认会搜索所列源文件的父目录。还可以用 `--include-dir` 指定其他头文件搜索目录，或用 `--rtl-filelist` 指定另一份同格式清单：

```sh
python3 dse/dse.py run --name baseline --rtl-filelist dse/rtl.f --include-dir src
```

要探索架构参数，先在自己的 RTL 中定义相应参数，再通过 `--param 参数名=整数` 传入。以下仅为用法示例，`P_OC`、`P_IC` 不是模板已有参数：

```sh
python3 dse/dse.py run --name p2 --param P_OC=2 --param P_IC=2
python3 dse/dse.py run --name p4 --param P_OC=4 --param P_IC=2
```

配置名用于辨认结果，不会改变硬件。未在 RTL 中定义的参数不能作为有效的探索变量。可以比较并行度、累加结构、流水级数或缓冲组织，也可以修改 RTL 后用不同配置名分别运行；每种实现都应独立验证正确性。入口会保留本次 RTL 快照和参数记录，便于回溯结果。

可选择一到两个变量探索，例如：

| 设计变量 | 可尝试的取值／方案（仅供参考） |
| --- | --- |
| 每周期并行处理的乘积数 | 1、2、4、8 |
| 输出通道并行度 | 1、2、3（benchmark 共 3 个输出通道） |
| 流水与累加结构 | 增减流水级，串行累加或加法树 |
| 缓冲与数据复用 | 缓冲分组、输入／权重／部分和驻留方式 |

这些变化需要自行在 RTL 中实现；保持计算精度和功能不变。

`--param` 只覆盖本次综合的参数，只影响综合，不会修改 RTL 默认值，也不会传给 `make vcs` 或 `make xrun`。
（最简单的做法是先将 RTL 中的架构参数默认值改为待测值，跑通功能测试，再运行综合）

## 3. 固定比较条件

所有配置使用相同的功能规模、库和约束。入口显式指定八个功能参数，不能通过 `--param` 改变它们后将结果与其他配置直接比较。

| 项目 | 统一设置 |
| --- | --- |
| 综合工具 | Cadence Genus；generic、map、opt effort 均为 medium，最多使用 2 个 CPU |
| 综合顶层 | `conv_accel` |
| 功能参数 | `IN_H=5, IN_W=6, IN_C=2, OUT_C=3, K_H=3, K_W=3, STRIDE=1, PAD=1`，与 benchmark 的三帧一致 |
| 库及角落 | GPDK045 教学示例库，typical，1.2 V，25°C |
| 时钟 | 10 ns 理想时钟，目标频率 100 MHz |
| 非时钟输入 | 输入延迟 1 ns，数据输入 transition 0.1 ns |
| 输出 | 输出延迟 1 ns，每个输出端口位负载 0.01 pF |
| 面积指标 | 顶层标准单元面积 `Cell Area`，单位 µm² |

数据输入的 transition 和输入输出延迟属于统一的外部接口条件，会影响单元选择，因此比较时保持不变。`rst_n` 是同步复位输入，按正常输入约束，不添加 false path。

10 ns 是综合目标；如果报告显示时序违例，入口仍保存面积和时序结果，并将 `timing_met` 记为 `false`。

## 4. 查看结果

每个运行目录包含以下内容：

| 文件 | 用途 |
| --- | --- |
| `summary.json`、`summary.csv` | 本次面积、时序等提取结果，便于汇总比较 |
| `area.rpt` | 原始面积报告，读取顶层 `Cell Area` |
| `gates.rpt` | 映射单元类型、数量和面积 |
| `timing.rpt` | 最差路径和 slack，检查 MET／VIOLATED |
| `mapped.v`、`mapped.sdc` | 综合网表及实际采用的约束 |
| `genus.log` | 综合日志，失败时从这里定位原因 |
| `run_manifest.json`、RTL 快照 | 本次源文件、参数及运行条件的记录 |

显式指定参数后，Genus 可能把顶层命名为 `conv_accel_IN_H5_IN_W6_...`；读取报告标题 `Module` 对应的顶层行即可。

这里的面积包含计算、控制，以及用触发器实现的输入、权重等存储。逻辑综合的 `Net Area` 暂时不纳入考虑。

每个 `summary.csv` 只记录本次配置；比较时汇集各目录中的结果。该流程面向通过接口装载输入和权重的 RTL，不支持依赖仿真运行目录的 `$readmemh` 等外部初始化文件。

## 5. 周期数与面积的帕累托比较

统一 benchmark 为 **C09 第 1 帧、C10 第 1 帧和第 2 帧**。三帧尺寸相同、数据不同，计算期间 `out_ready=1`。接受 `start` 的时钟沿记为第 0 拍，统计至最后一次输出握手；不计装载、复位及帧间空闲时间。

每组配置先运行全量 `make vcs`（或 `make xrun`），确认 10/10 通过。从本次 `build/vcs/sim.log`（或 `build/xrun/sim.log`）中读取三条 `[FRAME] C09/C10` 的 `in N cycles` 数值，计算：

```text
平均周期数 = (C09 第1帧周期数 + C10 第1帧周期数 + C10 第2帧周期数) / 3
```

注意保存每组配置对应的全量日志：再次运行全量或单例仿真会覆盖同一工具目录中的 `sim.log`，综合入口也不会备份该日志。切换配置或调试其他用例前，请先将全量日志、源码及参数记录保存到独立目录。

面积取该配置一次综合所得的 `cell_area_um2`；平均周期数由上述仿真日志计算，不在当前 DSE 汇总文件中自动生成。比较各配置的“面积、平均周期数”，两项均越小越好。如果另一个配置两项都不大于当前配置且至少一项更小，当前配置就被支配；未被其他有效配置支配的点组成帕累托前沿。

