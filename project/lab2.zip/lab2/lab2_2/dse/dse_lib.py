"""Prepare the course's cached GPDK045 Liberty without changing source files.

This module deliberately supports the installed GPDK045 example, rather than
claiming to be a general Liberty/LEF parser. It uses only Python 3.6+ stdlib.
"""

import hashlib
import json
import os
import re
import tempfile
import time
from contextlib import contextmanager
from decimal import Decimal
from pathlib import Path


SCHEMA_VERSION = 2
LIBRARY_NAME = "aiarch_lab2_2"
EXPECTED_CELL_COUNT = 477
_NUMBER = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?"


def _sha256(data):
    return hashlib.sha256(data).hexdigest()


def _mask_comments(text):
    """Mask comments without changing offsets or interpreting quoted text."""
    token = re.compile(r'"(?:\\.|[^"\\])*"|/\*[\s\S]*?\*/|//[^\r\n]*')

    def mask(match):
        value = match.group(0)
        if value.startswith('"'):
            return value
        return re.sub(r"[^\r\n]", " ", value)

    return token.sub(mask, text)


def _brace_end(masked, opening):
    """Find a block's closing brace, ignoring braces in quoted strings."""
    depth = 0
    quoted = False
    escaped = False
    for position in range(opening, len(masked)):
        char = masked[position]
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return position
    raise ValueError("Unbalanced braces in source Liberty")


def _lef_areas(lef):
    # A commented duplicate ANTENNA macro is present in the installed LEF.
    lef = re.sub(r"(?m)^[ \t]*#[^\r\n]*", "", lef)
    pattern = re.compile(
        r"^[ \t]*MACRO[ \t]+(\w+)[ \t]*\r?\n"
        r"(.*?)^[ \t]*END[ \t]+\1[ \t]*\r?$",
        re.M | re.S,
    )
    sizes = {}
    for macro in pattern.finditer(lef):
        name = macro.group(1)
        if name in sizes:
            raise ValueError("Duplicate LEF macro: " + name)
        size = re.search(
            r"^[ \t]*SIZE\s+(" + _NUMBER + r")\s+BY\s+(" + _NUMBER + r")\s*;",
            macro.group(2), re.M,
        )
        if size is None:
            raise ValueError("LEF macro lacks SIZE: " + name)
        width, height = (Decimal(value) for value in size.groups())
        if width <= 0 or height <= 0:
            raise ValueError("Nonpositive LEF dimensions: " + name)
        sizes[name] = width * height
    if not sizes:
        raise ValueError("No LEF MACRO/SIZE records found")
    return sizes


def _derive_library(lib, lef):
    masked = _mask_comments(lib)
    library = list(re.finditer(r'\blibrary\s*\(\s*"?([\w.-]+)"?\s*\)\s*\{', masked))
    if len(library) != 1:
        raise ValueError("Expected exactly one library block")
    if library[0].group(1) != "typical":
        raise ValueError("Only the course GPDK045 typical library is supported")
    for attribute, expected in (("nom_voltage", Decimal("1.2")),
                                ("nom_temperature", Decimal("25"))):
        values = re.findall(r"\b" + attribute + r"\s*:\s*(" + _NUMBER + r")\s*;", masked)
        if len(values) != 1 or Decimal(values[0]) != expected:
            raise ValueError("GPDK045 corner must be typical, 1.2 V, 25 C: " + attribute)
    cells = list(re.finditer(r'\bcell\s*\(\s*"?(\w+)"?\s*\)\s*\{', masked))
    names = [cell.group(1) for cell in cells]
    if len(cells) != EXPECTED_CELL_COUNT or len(set(names)) != len(names):
        raise ValueError("Expected 477 unique GPDK045 cells; source library changed")

    lef_areas = _lef_areas(lef)
    missing = sorted(set(names) - set(lef_areas))
    if missing:
        raise ValueError("Liberty cells missing from LEF: " + ", ".join(missing))

    edits = [(library[0].start(1), library[0].end(1), LIBRARY_NAME)]
    area_pattern = re.compile(r"\barea\s*:\s*(" + _NUMBER + r")\s*;")
    patched = 0
    for cell in cells:
        name = cell.group(1)
        opening = cell.end() - 1
        closing = _brace_end(masked, opening)
        area = area_pattern.search(masked, opening + 1, closing)
        if area is None:
            edits.append((opening + 1, opening + 1,
                          "\n  area : " + format(lef_areas[name], "f") + ";"))
            patched += 1
        else:
            value = Decimal(area.group(1))
            if value < 0:
                raise ValueError("Negative Liberty cell area: " + name)
            if value == 0:
                edits.append((area.start(1), area.end(1), format(lef_areas[name], "f")))
                patched += 1
            # Preserve an existing positive area exactly, including formatting.

    result = lib
    for start, stop, replacement in sorted(edits, reverse=True):
        result = result[:start] + replacement + result[stop:]
    return result, {
        "cell_count": len(cells),
        "patched_cell_count": patched,
        "preserved_cell_count": len(cells) - patched,
    }


def _atomic_write(path, data):
    descriptor, temporary = tempfile.mkstemp(prefix=".prepare-", dir=str(path.parent))
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, str(path))
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


@contextmanager
def _cache_lock(cache_dir):
    lock = cache_dir / ".prepare.lock"
    deadline = time.monotonic() + 30.0
    while True:
        try:
            lock.mkdir()
            break
        except FileExistsError:
            if time.monotonic() >= deadline:
                raise RuntimeError("Library cache is locked: {}. Another preparation may "
                                   "be running; inspect before removing a stale lock.".format(lock))
            time.sleep(0.1)
    try:
        yield
    finally:
        lock.rmdir()


def prepare_library(source_lib, source_lef, cache_dir):
    """Return (library_path, manifest, reused) for the course library cache.

    ``source_lib``, ``source_lef`` and ``cache_dir`` accept pathlib.Path values.
    Missing/zero area is filled using the same-named LEF macro's width * height;
    positive existing area is preserved. Negative area or unmatched cells fail.
    A verified existing cache is reused without rewriting it. Stale, partial or
    edited caches fail explicitly so different experiments cannot silently use
    different libraries. The caller may select a new cache directory after
    investigating a mismatch.
    """
    source_lib = Path(source_lib).resolve()
    source_lef = Path(source_lef).resolve()
    cache_dir = Path(cache_dir).resolve()
    library_path = cache_dir / (LIBRARY_NAME + ".lib")
    manifest_path = cache_dir / "library_manifest.json"
    if library_path in (source_lib, source_lef) or manifest_path in (source_lib, source_lef):
        raise ValueError("Cache paths must not overwrite a source file")

    lib_bytes = source_lib.read_bytes()
    lef_bytes = source_lef.read_bytes()
    identity = {
        "schema_version": SCHEMA_VERSION,
        "library_name": LIBRARY_NAME,
        "source_lib_sha256": _sha256(lib_bytes),
        "source_lef_sha256": _sha256(lef_bytes),
    }
    cache_dir.mkdir(parents=True, exist_ok=True)
    with _cache_lock(cache_dir):
        if library_path.exists() or manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                consistent = (
                    all(manifest.get(key) == value for key, value in identity.items())
                    and manifest.get("derived_lib_sha256") == _sha256(library_path.read_bytes())
                    and manifest.get("cell_count") == EXPECTED_CELL_COUNT
                )
            except (OSError, ValueError, AttributeError):
                consistent = False
            if not consistent:
                raise RuntimeError("Library cache is stale, partial or edited: {}. "
                                   "Inspect it and use a new cache directory; it was not overwritten."
                                   .format(cache_dir))
            return library_path, manifest, True

        derived, counts = _derive_library(lib_bytes.decode("utf-8"), lef_bytes.decode("utf-8"))
        derived_bytes = derived.encode("utf-8")
        manifest = dict(identity)
        manifest.update(counts)
        manifest.update({
            "source_lib": str(source_lib),
            "source_lef": str(source_lef),
            "derived_lib": str(library_path),
            "derived_lib_sha256": _sha256(derived_bytes),
            "area_rule": "Preserve positive Liberty area; fill missing/zero area with LEF SIZE width * height",
            "area_unit": "um^2",
            "corner": "typical, 1.2 V, 25 C",
        })
        _atomic_write(library_path, derived_bytes)
        _atomic_write(manifest_path, (json.dumps(manifest, indent=2) + "\n").encode("utf-8"))
        return library_path, manifest, False
