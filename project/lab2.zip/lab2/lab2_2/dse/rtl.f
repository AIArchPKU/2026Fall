# Paths are relative to lab2_2, not to this file.
# Add student hardware modules here; do not add the testbench.
src/conv_accel.v
