#!/usr/bin/env python3
"""Prepare the teaching library and run repeatable Genus area experiments.

Uses Python 3.6+ and its standard library. No accelerator implementation here.
Run `python3 dse/dse.py --help` from lab2_2 (or use an absolute script path).
"""

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid

from dse_lib import prepare_library


LAB_ROOT = Path(__file__).resolve().parents[1]
DSE_ROOT = LAB_ROOT / 'dse'
BUILD_ROOT = LAB_ROOT / 'build' / 'dse'
PDK_ROOT = Path('/opt/eda/Cadence/INNOVUS211/share/FoundationFlows/EXAMPLES/'
                'INNOVUS/DESIGN/GPDK/LIBS/GPDK045')
FUNCTIONAL = dict(IN_H=5, IN_W=6, IN_C=2, OUT_C=3,
                  K_H=3, K_W=3, STRIDE=1, PAD=1)
CONDITIONS = {
    'top': 'conv_accel', 'corner': 'typical, 1.2 V, 25 C',
    'clock_period_ns': 10.0, 'clock_model': 'ideal',
    'input_delay_ns': 1.0, 'output_delay_ns': 1.0,
    'data_input_transition_ns': 0.1, 'output_load_pf': 0.01,
    'synthesis_effort': 'medium', 'max_cpus': 2,
    'area_unit': 'um^2', 'power_analysis': False,
}
SOURCE_SUFFIXES = {'.v', '.sv'}
INPUT_SUFFIXES = SOURCE_SUFFIXES | {'.vh', '.svh'}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n',
                    encoding='utf-8')


def lab_path(value):
    path = Path(value)
    if not path.is_absolute():
        path = LAB_ROOT / path
    path = path.resolve()
    try:
        path.relative_to(LAB_ROOT)
    except ValueError:
        raise ValueError('RTL and include paths must be inside lab2_2: ' + str(path))
    return path


def load_inputs(filelist, extra_dirs):
    """Simple hardware file list, plus snapshots of nearby include files."""
    filelist = lab_path(filelist)
    files = []
    for line in filelist.read_text(encoding='utf-8').splitlines():
        value = line.strip()
        if not value or value.startswith(('#', '//')):
            continue
        path = lab_path(value)
        if not path.is_file() or path.suffix.lower() not in INPUT_SUFFIXES:
            raise ValueError('Expected an RTL or header file: ' + value)
        if re.search(r'(?i)(?:testbench|_tb\.)', path.name):
            raise ValueError('Testbenches must not be synthesized: ' + value)
        if path not in files:
            files.append(path)
    rtl = [p for p in files if p.suffix.lower() in SOURCE_SUFFIXES]
    if not rtl:
        raise ValueError('No RTL source files found in ' + str(filelist))
    includes = []
    for path in [p.parent for p in files] + [lab_path(p) for p in extra_dirs]:
        if not path.is_dir():
            raise ValueError('Include directory does not exist: ' + str(path))
        # Including build/ would recursively capture previous results.
        if path == LAB_ROOT or LAB_ROOT / 'build' == path or LAB_ROOT / 'build' in path.parents:
            raise ValueError('Use a source directory such as src for includes: ' + str(path))
        if path not in includes:
            includes.append(path)
    inputs = set(files)
    for folder in includes:
        for path in folder.rglob('*'):
            if path.is_file() and path.suffix.lower() in INPUT_SUFFIXES:
                # Avoid silently importing symlinks that point outside this lab.
                resolved = lab_path(path)
                inputs.add(resolved)
    return filelist, rtl, includes, sorted(inputs)


def parse_params(values):
    params = {}
    for value in values:
        match = re.fullmatch(r'([A-Za-z_][A-Za-z0-9_]*)=(-?\d+)', value)
        if not match:
            raise ValueError('Use an integer architecture parameter: NAME=VALUE')
        name, number = match.groups()
        if name in FUNCTIONAL:
            raise ValueError('Functional parameters are fixed to C03: ' + name)
        if name in params:
            raise ValueError('Duplicate parameter: ' + name)
        params[name] = int(number)
    # Genus checks names after preprocessing the actual HDL, including parameter
    # declarations in headers and optional SystemVerilog module lifetimes.
    # It rejects unknown overrides with CDFG-214; regex cannot parse this syntax.
    return params


def tcl_string(value):
    """Quote a literal, including special characters in file paths."""
    value = str(value)
    for old, new in [('\\', '\\\\'), ('"', '\\"'), ('$', '\\$'),
                     ('[', '\\['), (']', '\\]'), ('\n', '\\n'), ('\r', '\\r')]:
        value = value.replace(old, new)
    return '"' + value + '"'


def tcl_list(values):
    return '[list ' + ' '.join(tcl_string(v) for v in values) + ']'


def parse_reports(area_text, timing_text):
    module = re.search(r'^\s*Module:\s*(\S+)', area_text, re.M)
    if not module:
        raise ValueError('Cannot find the top module in area.rpt')
    # Module column may be empty; the numeric columns are at the end of the row.
    row = re.search(r'^\s*' + re.escape(module.group(1)) +
                    r'\s+(?:\S+\s+)?(\d+)\s+([\d.eE+-]+)\s+'
                    r'([\d.eE+-]+)\s+([\d.eE+-]+)(?:\s|$)', area_text, re.M)
    if not row:
        raise ValueError('Cannot parse the top Cell Area row in area.rpt')
    count, area = int(row.group(1)), float(row.group(2))
    slack = re.search(r'Path\s+1:\s+(MET|VIOLATED)\s+\(([-+\d.eE]+)\s+ps\)', timing_text)
    if slack:
        timing_met = slack.group(1) == 'MET'
        slack_ps = float(slack.group(2))
        if not timing_met:
            slack_ps = -abs(slack_ps)
    elif 'No paths found' in timing_text:
        timing_met, slack_ps = None, None
    else:
        raise ValueError('Cannot parse the worst path in timing.rpt')
    return {'mapped_top': module.group(1), 'cell_count': count,
            'cell_area_um2': area, 'worst_slack_ns': None if slack_ps is None else slack_ps / 1000,
            'timing_met': timing_met}


def summary_files(out, summary):
    write_json(out / 'summary.json', summary)
    columns = ['name', 'status', 'cell_count', 'cell_area_um2', 'worst_slack_ns',
               'timing_met', 'clock_period_ns', 'architecture_params', 'run_directory']
    row = dict(summary)
    row['architecture_params'] = json.dumps(summary['architecture_params'], sort_keys=True)
    with (out / 'summary.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        writer.writerow(row)


def run_area(args):
    executable = shutil.which(args.genus)
    if not executable:
        raise ValueError('Cannot find Genus; run: source /etc/profile.d/eda.sh')
    # Keep a tool-launcher symlink's basename: Cadence's shared wrapper uses
    # argv[0] to select Genus. Only make relative paths absolute before chdir.
    executable = os.path.abspath(executable)
    filelist, rtl, includes, inputs = load_inputs(args.rtl_filelist, args.include_dir)
    arch = parse_params(args.param)
    library, library_manifest, reused = prepare_library(
        Path(args.liberty), Path(args.lef), BUILD_ROOT / 'lib')
    print(('Reusing' if reused else 'Prepared') + ' library: ' + str(library), flush=True)
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}', args.name):
        raise ValueError('Run name must be 1-64 letters, digits, dots, underscores or hyphens')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    out = BUILD_ROOT / 'runs' / (args.name + '_' + stamp + '_' + uuid.uuid4().hex[:8])
    out.mkdir(parents=True)
    summary = {'name': args.name, 'status': 'failed', 'architecture_params': arch,
               'functional_params': FUNCTIONAL, 'clock_period_ns': 10.0,
               'run_directory': str(out), 'library_reused': reused,
               'functional_test': 'not_run_by_dse'}
    print('Run directory: ' + str(out), flush=True)
    try:
        snapshots = []
        for path in inputs:
            relative = path.relative_to(LAB_ROOT)
            target = out / 'inputs' / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(path.read_bytes())
            snapshots.append({'path': relative.as_posix(), 'sha256': sha256(target)})
        shutil.copyfile(filelist, out / 'rtl.f')
        shutil.copyfile(DSE_ROOT / 'ideal_clock.sdc', out / 'ideal_clock.sdc')
        shutil.copyfile(DSE_ROOT / 'synth_area.tcl', out / 'synth_area.tcl')
        write_json(out / 'library_manifest.json', library_manifest)
        settings = dict(FUNCTIONAL)
        settings.update(arch)
        config = [
            'set library_file ' + tcl_string(library),
            'set constraint_file ' + tcl_string(out / 'ideal_clock.sdc'),
            'set rtl_files ' + tcl_list(out / 'inputs' / p.relative_to(LAB_ROOT) for p in rtl),
            'set include_dirs ' + tcl_list([out / 'inputs'] + [out / 'inputs' / p.relative_to(LAB_ROOT) for p in includes]),
            'set parameters [list ' + ' '.join('[list ' + tcl_string(k) + ' ' +
                                               str(v) + ']' for k, v in settings.items()) + ']',
        ]
        (out / 'config.tcl').write_text('\n'.join(config) + '\n', encoding='utf-8')
        manifest = {'conditions': CONDITIONS, 'functional_params': FUNCTIONAL,
                    'architecture_params': arch, 'rtl_files': [str(p.relative_to(LAB_ROOT)) for p in rtl],
                    'input_files': snapshots, 'genus_executable': executable,
                    'constraint_sha256': sha256(out / 'ideal_clock.sdc'),
                    'synthesis_script_sha256': sha256(out / 'synth_area.tcl'),
                    'runner_sha256': sha256(Path(__file__)),
                    'library_sha256': sha256(library), 'created_utc': stamp}
        write_json(out / 'run_manifest.json', manifest)
        env = os.environ.copy()
        env['DSE_CONFIG'] = str(out / 'config.tcl')
        with (out / 'genus.log').open('w', encoding='utf-8') as log:
            result = subprocess.run([executable, '-no_gui', '-files', str(out / 'synth_area.tcl')],
                                    cwd=str(out), env=env, stdout=log, stderr=subprocess.STDOUT)
        log_text = (out / 'genus.log').read_text(encoding='utf-8', errors='replace')
        if result.returncode or not re.search(r'^DSE_AREA_DONE\s*$', log_text, re.M):
            raise ValueError('Genus did not finish successfully; inspect genus.log')
        if re.search(r'^\s*(?:Error|ERROR|Fatal|FATAL)(?:\s|:)', log_text, re.M):
            raise ValueError('Genus reported an error; inspect genus.log')
        for name in ['area.rpt', 'gates.rpt', 'timing.rpt', 'mapped.v', 'mapped.sdc',
                     'check_design.rpt', 'check_design_mapped.rpt']:
            if not (out / name).is_file() or not (out / name).stat().st_size:
                raise ValueError('Missing report: ' + name)
        for name in ['check_design.rpt', 'check_design_mapped.rpt']:
            if 'No unresolved references' not in (out / name).read_text(errors='replace'):
                raise ValueError('Unresolved reference check failed: ' + name)
        metrics = parse_reports((out / 'area.rpt').read_text(), (out / 'timing.rpt').read_text())
        summary.update(metrics)
        if metrics['cell_count'] <= 0 or metrics['cell_area_um2'] <= 0:
            summary['status'] = 'empty_design'
            raise ValueError('No mapped hardware: implement the RTL before DSE')
        if metrics['timing_met'] is None:
            raise ValueError('No timed path found; inspect the design and clock constraints')
        summary['status'] = 'ok' if metrics['timing_met'] else 'timing_violation'
        summary_files(out, summary)
        print('Cell Area: {:.3f} um^2; cells: {}; worst slack: {:.3f} ns; timing: {}'.format(
            metrics['cell_area_um2'], metrics['cell_count'], metrics['worst_slack_ns'],
            'MET' if metrics['timing_met'] else 'VIOLATED'))
        print('Summary: ' + str(out / 'summary.json'))
        return 0
    except (OSError, ValueError, RuntimeError) as error:
        summary['error'] = str(error)
        summary_files(out, summary)
        raise ValueError(str(error) + '\nReports: ' + str(out))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--liberty', default=str(PDK_ROOT / 'timing' / 'typical.lib'))
    parser.add_argument('--lef', default=str(PDK_ROOT / 'gsclib045.lef'))
    commands = parser.add_subparsers(dest='command')
    commands.add_parser('prepare-lib', help='prepare or validate the reusable aiarch_lab2_2 library')
    run = commands.add_parser('run', help='synthesize one student design configuration')
    run.add_argument('--name', default='baseline')
    run.add_argument('--param', action='append', default=[], metavar='NAME=INTEGER')
    run.add_argument('--rtl-filelist', default='dse/rtl.f')
    run.add_argument('--include-dir', action='append', default=[])
    run.add_argument('--genus', default='genus')
    args = parser.parse_args()
    try:
        if args.command == 'prepare-lib':
            path, manifest, reused = prepare_library(Path(args.liberty), Path(args.lef), BUILD_ROOT / 'lib')
            print(('Reusing' if reused else 'Prepared') + ' library: ' + str(path))
            print('Library cells: ' + str(manifest.get('cell_count', 'see library_manifest.json')))
            return 0
        if args.command == 'run':
            return run_area(args)
        parser.print_help()
        return 2
    except (OSError, ValueError, RuntimeError) as error:
        print('DSE failed: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
