`timescale 1ns/1ps
`default_nettype none

// The testbench uses only the public DUT interface. It does not inspect DUT state.
module conv_accel_case #(
    parameter integer ID = 1,
    parameter CASE_NAME = "tiny_signed",
    parameter integer IN_H = 5,
    parameter integer IN_W = 6,
    parameter integer IN_C = 2,
    parameter integer OUT_C = 3,
    parameter integer K_H = 3,
    parameter integer K_W = 3,
    parameter integer STRIDE = 1,
    parameter integer PAD = 1,
    parameter integer HALF_PERIOD_NS = 5
) (
    input  wire clk,
    input  wire enabled,
    output reg  finished,
    output reg  failed
);
    localparam integer OUT_H = (IN_H + 2*PAD - K_H)/STRIDE + 1;
    localparam integer OUT_W = (IN_W + 2*PAD - K_W)/STRIDE + 1;
    localparam integer NUM_INPUTS = IN_H*IN_W*IN_C;
    localparam integer NUM_WEIGHTS = OUT_C*K_H*K_W*IN_C;
    localparam integer NUM_OUTPUTS = OUT_H*OUT_W*OUT_C;
    localparam integer MAX_FRAME_CYCLES = 100000;
    // Build C01...C10 explicitly: some simulators space-pad %02d.
    localparam [23:0] CASE_LABEL = 24'h433030 + 256*(ID/10) + ID%10;

    reg rst_n, load_we, load_sel, start, out_ready;
    reg [15:0] load_addr;
    reg signed [7:0] load_data;
    wire busy, done, out_valid;
    wire signed [31:0] out_data;

    integer image [0:NUM_INPUTS-1];
    integer weight [0:NUM_WEIGHTS-1];
    reg signed [31:0] expected [0:NUM_OUTPUTS-1];
    integer frame_number;

    conv_accel #(
        .IN_H(IN_H), .IN_W(IN_W), .IN_C(IN_C), .OUT_C(OUT_C),
        .K_H(K_H), .K_W(K_W), .STRIDE(STRIDE), .PAD(PAD)
    ) dut (
        .clk(clk), .rst_n(rst_n), .load_we(load_we), .load_sel(load_sel),
        .load_addr(load_addr), .load_data(load_data), .start(start),
        .busy(busy), .done(done), .out_valid(out_valid),
        .out_ready(out_ready), .out_data(out_data)
    );

    // End just this case on its first failure; the other DUTs keep running.
    task automatic fail(input string reason);
        $display("[FAIL] %0s %0s frame %0d at %0t: %0s",
                 CASE_LABEL, CASE_NAME, frame_number, $time, reason);
        failed = 1;
        finished = 1;
        disable run_case;
    endtask

    task automatic check_idle;
        if (busy !== 1'b0 || done !== 1'b0 || out_valid !== 1'b0)
            fail($sformatf("expected idle: busy=%b done=%b out_valid=%b",
                           busy, done, out_valid));
    endtask

    // Drive on falling edges. Check handshake signals 1 ns before the rising
    // edge and updated state 1 ns after it to avoid races with DUT logic.
    task automatic idle_cycle;
        @(negedge clk);
        start = 0;
        load_we = 0;
        out_ready = 1;
        @(posedge clk);
        #1;
        check_idle();
    endtask

    task automatic reset_core;
        @(negedge clk);
        rst_n = 0;
        start = 0;
        load_we = 0;
        out_ready = 0;
        repeat (2) begin
            @(posedge clk);
            #1;
            check_idle();
        end
        @(negedge clk);
        rst_n = 1;
        idle_cycle();
    endtask

    task automatic load_word(input bit sel, input integer addr, input integer value);
        @(negedge clk);
        start = 0;
        load_we = 1;
        load_sel = sel;
        load_addr = addr;
        load_data = value;
        @(posedge clk);
        #1;
        check_idle();
    endtask

    task automatic load_tensors(input bit write_weights, input bit reverse_order);
        integer i, addr;
        if (write_weights) begin
            for (i = 0; i < NUM_WEIGHTS; i = i + 1) begin
                addr = reverse_order ? NUM_WEIGHTS-1-i : i;
                load_word(1, addr, weight[addr]);
            end
        end
        for (i = 0; i < NUM_INPUTS; i = i + 1) begin
            addr = reverse_order ? NUM_INPUTS-1-i : i;
            load_word(0, addr, image[addr]);
            if (reverse_order && i % 7 == 3)
                idle_cycle();
        end
    endtask

    task automatic make_pattern(input integer seed, input bit change_weights);
        integer i;
        for (i = 0; i < NUM_INPUTS; i = i + 1)
            image[i] = ((i*i*11 + i*29 + seed*13 + 99) % 253) - 126;
        if (change_weights)
            for (i = 0; i < NUM_WEIGHTS; i = i + 1)
                weight[i] = ((i*i*17 + i*41 + seed*53 + 101) % 251) - 125;
    endtask

    // Untimed cross-correlation on signed integers; no DUT dataflow assumptions.
    task automatic build_expected;
        integer oy, ox, oc, ky, kx, ic, iy, ix, acc, n;
        n = 0;
        for (oy = 0; oy < OUT_H; oy = oy + 1)
            for (ox = 0; ox < OUT_W; ox = ox + 1)
                for (oc = 0; oc < OUT_C; oc = oc + 1) begin
                    acc = 0;
                    for (ky = 0; ky < K_H; ky = ky + 1)
                        for (kx = 0; kx < K_W; kx = kx + 1) begin
                            iy = oy*STRIDE + ky - PAD;
                            ix = ox*STRIDE + kx - PAD;
                            if (iy >= 0 && iy < IN_H && ix >= 0 && ix < IN_W)
                                for (ic = 0; ic < IN_C; ic = ic + 1)
                                    acc = acc + image[(iy*IN_W+ix)*IN_C+ic]
                                              * weight[((oc*K_H+ky)*K_W+kx)*IN_C+ic];
                        end
                    expected[n] = acc;
                    n = n + 1;
                end
    endtask

    task automatic run_frame(input bit backpressure, input bit probe_busy,
                             input bit abort_frame);
        integer cycle, received, first_stall, stall_after;
        bit was_stalled, last_beat;
        reg signed [31:0] held_data;
        begin : frame
            frame_number = frame_number + 1;
            received = 0;
            was_stalled = 0;
            first_stall = backpressure ? 3 : 0;
            stall_after = abort_frame ? 2 : 0;

            @(negedge clk);
            load_we = 0;
            start = 1;
            out_ready = !backpressure || stall_after != 0;
            #(HALF_PERIOD_NS-1);
            check_idle();
            @(posedge clk);
            #1;
            if (busy !== 1'b1 || done !== 1'b0)
                fail($sformatf("start was not accepted: busy=%b done=%b", busy, done));

            for (cycle = 0; cycle < MAX_FRAME_CYCLES; cycle = cycle + 1) begin
                @(negedge clk);
                start = probe_busy && (cycle == 1);
                load_we = probe_busy && (cycle == 2 || cycle == 3);
                load_addr = 0;
                load_sel = (cycle == 3);
                load_data = load_sel ? ~weight[0] : ~image[0];
                // Force a pending result to stall, then vary ready.
                out_ready = (received < stall_after) || ((first_stall == 0) &&
                            (!backpressure || (cycle % 11 >= 3)));

                #(HALF_PERIOD_NS-1);
                if (busy !== 1'b1 || done !== 1'b0)
                    fail($sformatf("before result %0d: busy=%b done=%b",
                                   received, busy, done));
                if (out_valid !== 1'b0 && out_valid !== 1'b1)
                    fail("out_valid is X or Z");
                if (was_stalled && (out_valid !== 1'b1 || out_data !== held_data))
                    fail($sformatf("out_valid/out_data changed during a stall at result %0d",
                                   received));

                last_beat = 0;
                if (out_valid) begin
                    if (out_data !== expected[received])
                        fail($sformatf("output[%0d][%0d][%0d] expected %0d, got %0d (0x%08h)",
                                       received/(OUT_W*OUT_C), received/OUT_C%OUT_W,
                                       received%OUT_C, expected[received], out_data, out_data));
                    if (out_ready) begin
                        received = received + 1;
                        last_beat = (received == NUM_OUTPUTS);
                    end else begin
                        held_data = out_data;
                        if (first_stall > 0)
                            first_stall = first_stall - 1;
                    end
                end
                was_stalled = out_valid && !out_ready;

                @(posedge clk);
                #1;
                if (last_beat) begin
                    if (busy !== 1'b0 || done !== 1'b1 || out_valid !== 1'b0)
                        fail($sformatf("after last transfer: expected busy=0 done=1 out_valid=0, got %b %b %b",
                                       busy, done, out_valid));
                    // The next rising edge must clear the done pulse.
                    repeat (2) idle_cycle();
                    $display("[FRAME] %0s frame %0d: %0d outputs in %0d cycles",
                             CASE_LABEL, frame_number, received, cycle+1);
                    disable frame;
                end
                if (busy !== 1'b1 || done !== 1'b0)
                    fail($sformatf("after %0d/%0d transfers: busy=%b done=%b",
                                   received, NUM_OUTPUTS, busy, done));

                if (abort_frame && first_stall == 0) begin
                    reset_core();
                    $display("[FRAME] %0s frame %0d: reset during a stall after %0d/%0d outputs",
                             CASE_LABEL, frame_number, received, NUM_OUTPUTS);
                    disable frame;
                end
            end
            fail($sformatf("timeout after %0d cycles; received %0d/%0d outputs",
                           MAX_FRAME_CYCLES, received, NUM_OUTPUTS));
        end
    endtask

    integer i;
    initial begin : run_case
        finished = 0;
        failed = 0;
        frame_number = 0;
        rst_n = 0;
        load_we = 0;
        load_sel = 0;
        load_addr = 0;
        load_data = 0;
        start = 0;
        out_ready = 0;
        wait (enabled === 1'b1);
        reset_core();

        case (ID)
            1: begin // [[1,-2,3],[-4,5,-6]] correlated with [-2,3].
                image[0] = 1;  image[1] = -2; image[2] = 3;
                image[3] = -4; image[4] = 5;  image[5] = -6;
                weight[0] = -2; weight[1] = 3;
                for (i = 0; i < NUM_OUTPUTS; i = i + 1)
                    case (i)
                        0: expected[i] = -8;
                        1: expected[i] = 13;
                        2: expected[i] = 23;
                        3: expected[i] = -28;
                    endcase
                load_tensors(1, 0);
                run_frame(0, 0, 0);
            end
            2: begin // Known sums distinguish signed 32-bit and narrower accumulators.
                for (i = 0; i < NUM_INPUTS; i = i + 1)
                    image[i] = -128;
                for (i = 0; i < NUM_WEIGHTS; i = i + 1)
                    weight[i] = (i < NUM_WEIGHTS/2) ? -128 : 127;
                expected[0] = 524288;
                expected[1] = -520192;
                load_tensors(1, 0);
                run_frame(0, 0, 0);
            end
            3: begin
                make_pattern(3, 1);
                build_expected();
                load_tensors(1, 0);
                run_frame(1, 0, 0);
                make_pattern(19, 0);
                build_expected();
                load_tensors(0, 0); // New image, retained weights, no reset.
                run_frame(1, 0, 0);
            end
            4: begin
                make_pattern(4, 1);
                build_expected();
                load_tensors(1, 1);
                run_frame(0, 1, 0);
                // No writes between frames. The busy probes must not alter storage.
                run_frame(0, 0, 0);
            end
            5: begin
                make_pattern(5, 1);
                build_expected();
                load_tensors(1, 0);
                run_frame(1, 0, 1);
                make_pattern(23, 1);
                build_expected();
                load_tensors(1, 0);
                run_frame(0, 0, 0);
            end
            6: begin // A zero image after a nonzero frame must clear old sums.
                make_pattern(31, 1);
                build_expected();
                load_tensors(1, 0);
                run_frame(1, 0, 0);
                for (i = 0; i < NUM_INPUTS; i = i + 1)
                    image[i] = 0;
                build_expected();
                load_tensors(0, 1); // Retain weights and overwrite all pixels.
                run_frame(1, 0, 0);
            end
            7: begin // Sparse corner/channel impulses expose index mistakes.
                for (i = 0; i < NUM_INPUTS; i = i + 1)
                    image[i] = 0;
                for (i = 0; i < NUM_WEIGHTS; i = i + 1)
                    weight[i] = 0;
                image[0] = 127;
                image[(IN_W-1)*IN_C+1] = -128;
                image[((IN_H-1)*IN_W)*IN_C+1] = 63;
                image[(IN_H*IN_W-1)*IN_C] = -37;
                image[((IN_H/2)*IN_W+IN_W/2)*IN_C] = 19;
                for (i = 0; i < OUT_C; i = i + 1) begin
                    weight[((i*K_H)*K_W)*IN_C] = i + 1;
                    weight[((i*K_H+K_H/2)*K_W+K_W/2)*IN_C+1] = -3*(i+1);
                    weight[((i*K_H+K_H-1)*K_W+K_W-1)*IN_C] = 5*(i+1);
                end
                build_expected();
                load_tensors(1, 1);
                run_frame(1, 0, 0);
                // Change both tensors without resetting between frames.
                for (i = 0; i < NUM_INPUTS; i = i + 1)
                    image[i] = 0;
                image[1] = -91;
                image[(IN_H*IN_W-1)*IN_C+1] = 47;
                for (i = 0; i < NUM_WEIGHTS; i = i + 1)
                    weight[i] = 0;
                for (i = 0; i < OUT_C; i = i + 1)
                    weight[((i*K_H+K_H/2)*K_W+K_W/2)*IN_C+1] = 7*(i+1);
                build_expected();
                load_tensors(1, 0);
                run_frame(0, 0, 0);
            end
            8: begin // Large signed products nearly cancel across channels.
                for (i = 0; i < NUM_INPUTS; i = i + 1)
                    image[i] = (i % IN_C == 0) ? 127 : -126;
                for (i = 0; i < NUM_WEIGHTS; i = i + 1)
                    weight[i] = ((i/IN_C) % 2 == 0) ? 127 : -127;
                build_expected();
                load_tensors(1, 0);
                run_frame(0, 0, 0);
            end
            9: begin // Dense deterministic data, ready held high throughout.
                make_pattern(37, 1);
                build_expected();
                load_tensors(1, 0);
                run_frame(0, 0, 0);
            end
            10: begin // Two independent dense frames with full tensor reloads.
                make_pattern(83, 1);
                build_expected();
                load_tensors(1, 0);
                run_frame(0, 0, 0);
                make_pattern(109, 1);
                build_expected();
                load_tensors(1, 1);
                run_frame(0, 0, 0);
            end
            default: fail("unknown test case");
        endcase

        $display("[PASS] %0s %0s", CASE_LABEL, CASE_NAME);
        finished = 1;
    end
endmodule

module conv_accel_tb;
    localparam integer HALF_PERIOD_NS = 5;
    reg clk = 0;
    always #HALF_PERIOD_NS clk = ~clk;

    reg [9:0] enabled;
    wire [9:0] finished, failed;

    conv_accel_case #(.HALF_PERIOD_NS(HALF_PERIOD_NS),
        .ID(1), .CASE_NAME("tiny_signed"), .IN_H(2), .IN_W(3),
        .IN_C(1), .OUT_C(1), .K_H(1), .K_W(2), .STRIDE(1), .PAD(0))
        c01 (.clk(clk), .enabled(enabled[0]), .finished(finished[0]), .failed(failed[0]));

    conv_accel_case #(.HALF_PERIOD_NS(HALF_PERIOD_NS),
        .ID(2), .CASE_NAME("signed_extremes"), .IN_H(2), .IN_W(2),
        .IN_C(8), .OUT_C(2), .K_H(2), .K_W(2), .STRIDE(1), .PAD(0))
        c02 (.clk(clk), .enabled(enabled[1]), .finished(finished[1]), .failed(failed[1]));

    conv_accel_case #(.HALF_PERIOD_NS(HALF_PERIOD_NS),
        .ID(3), .CASE_NAME("padding_and_backpressure"))
        c03 (.clk(clk), .enabled(enabled[2]), .finished(finished[2]), .failed(failed[2]));

    conv_accel_case #(.HALF_PERIOD_NS(HALF_PERIOD_NS),
        .ID(4), .CASE_NAME("rectangular_stride_and_busy"), .IN_H(4), .IN_W(6),
        .IN_C(3), .OUT_C(2), .K_H(2), .K_W(3), .STRIDE(2), .PAD(1))
        c04 (.clk(clk), .enabled(enabled[3]), .finished(finished[3]), .failed(failed[3]));

    conv_accel_case #(.HALF_PERIOD_NS(HALF_PERIOD_NS),
        .ID(5), .CASE_NAME("reset_and_recovery"), .IN_H(3), .IN_W(4),
        .IN_C(2), .OUT_C(2), .K_H(2), .K_W(2), .STRIDE(1), .PAD(0))
        c05 (.clk(clk), .enabled(enabled[4]), .finished(finished[4]), .failed(failed[4]));

    // C06-C10 share the C03 dimensions; their data and operation sequences differ.
    conv_accel_case #(.HALF_PERIOD_NS(HALF_PERIOD_NS),
        .ID(6), .CASE_NAME("zero_after_nonzero"))
        c06 (.clk(clk), .enabled(enabled[5]), .finished(finished[5]), .failed(failed[5]));

    conv_accel_case #(.HALF_PERIOD_NS(HALF_PERIOD_NS),
        .ID(7), .CASE_NAME("sparse_corner_channels"))
        c07 (.clk(clk), .enabled(enabled[6]), .finished(finished[6]), .failed(failed[6]));

    conv_accel_case #(.HALF_PERIOD_NS(HALF_PERIOD_NS),
        .ID(8), .CASE_NAME("signed_cancellation"))
        c08 (.clk(clk), .enabled(enabled[7]), .finished(finished[7]), .failed(failed[7]));

    conv_accel_case #(.HALF_PERIOD_NS(HALF_PERIOD_NS),
        .ID(9), .CASE_NAME("dense_seed37"))
        c09 (.clk(clk), .enabled(enabled[8]), .finished(finished[8]), .failed(failed[8]));

    conv_accel_case #(.HALF_PERIOD_NS(HALF_PERIOD_NS),
        .ID(10), .CASE_NAME("dense_reload_seed83_109"))
        c10 (.clk(clk), .enabled(enabled[9]), .finished(finished[9]), .failed(failed[9]));

    integer i, passed, selected;
    reg [8*64-1:0] case_arg;
    // Keep the packed argument within Xcelium's $dumpfile width limit.
    reg [8*96-1:0] vcd_path;
    initial begin
        $timeformat(-9, 0, " ns", 0);
        selected = 0;
        if ($value$plusargs("case=%s", case_arg)) begin
            case (case_arg)
                "C01": selected = 1;
                "C02": selected = 2;
                "C03": selected = 3;
                "C04": selected = 4;
                "C05": selected = 5;
                "C06": selected = 6;
                "C07": selected = 7;
                "C08": selected = 8;
                "C09": selected = 9;
                "C10": selected = 10;
                default: $fatal(1, "Invalid +case=%0s; use C01 through C10", case_arg);
            endcase
        end else if ($test$plusargs("case=")) begin
            $fatal(1, "Missing case ID; use +case=C01 through +case=C10");
        end
        enabled = (selected == 0) ? 10'b1111111111 : (10'b0000000001 << (selected-1));

        if ($test$plusargs("vcd")) begin
            if (!$value$plusargs("vcdfile=%s", vcd_path))
                vcd_path = "conv_accel.vcd";
            $dumpfile(vcd_path);
            case (selected)
                1: $dumpvars(0, c01);
                2: $dumpvars(0, c02);
                3: $dumpvars(0, c03);
                4: $dumpvars(0, c04);
                5: $dumpvars(0, c05);
                6: $dumpvars(0, c06);
                7: $dumpvars(0, c07);
                8: $dumpvars(0, c08);
                9: $dumpvars(0, c09);
                10: $dumpvars(0, c10);
                default: $dumpvars(0, conv_accel_tb);
            endcase
        end

        wait (&(finished | ~enabled));
        if (selected != 0) begin
            if (failed[selected-1])
                $fatal(1, "TEST CASE %0s FAILED", case_arg);
            $display("TEST CASE %0s PASSED", case_arg);
        end else begin
            passed = 0;
            for (i = 0; i < 10; i = i + 1)
                if (!failed[i])
                    passed = passed + 1;
            if (passed != 10)
                $fatal(1, "TEST CASES FAILED (%0d/10 passed)", passed);
            $display("ALL TEST CASES PASSED (10/10)");
        end
        $finish;
    end
endmodule

`default_nettype wire
