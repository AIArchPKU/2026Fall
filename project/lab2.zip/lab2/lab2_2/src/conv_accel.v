`timescale 1ns/1ps
`default_nettype none

// Lab 2.2: implement the accelerator in this module.
// README.md defines the numerical operation and the interface timing.
module conv_accel #(
    parameter integer IN_H   = 5,
    parameter integer IN_W   = 6,
    parameter integer IN_C   = 2,
    parameter integer OUT_C  = 3,
    parameter integer K_H    = 3,
    parameter integer K_W    = 3,
    parameter integer STRIDE = 1,
    parameter integer PAD    = 1
) (
    input  wire               clk,
    input  wire               rst_n,      // Synchronous, active-low reset

    input  wire               load_we,
    input  wire               load_sel,   // 0: input [y][x][ic]; 1: weight [oc][ky][kx][ic]
    input  wire        [15:0] load_addr,
    input  wire signed  [7:0] load_data,

    input  wire               start,
    output wire               busy,
    output wire               done,       // One-cycle pulse immediately after the final transfer edge

    output wire               out_valid,
    input  wire               out_ready,
    output wire signed [31:0] out_data    // Output order: [oy][ox][oc]
);

    // TODO: replace these placeholders with your synthesizable design.
    assign busy      = 1'b0;
    assign done      = 1'b0;
    assign out_valid = 1'b0;
    assign out_data  = 32'sd0;

endmodule

`default_nettype wire
