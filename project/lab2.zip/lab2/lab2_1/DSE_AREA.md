# 设计空间探索：面积与平均 CPI

先让当前实现通过全部 **56 个测试**，再取得同一实现的综合面积。你可以探索设计空间，例如是否采用单指令执行、是否采用流水线、停顿、是否前馈、运算资源共享等。每次修改实现后，重新测试和综合。

你可以挑选几个感兴趣的方案或配置进行比较，并分析面积与平均 CPI 的取舍。

## 1. 测量一个配置

在 xLab 的 Bash 终端进入 `lab2_1`：

```sh
source /etc/profile.d/eda.sh
make test
```

全量通过后，控制台会给出仿真 `summary.json` 的路径。将该路径传给面积入口，例如：

```sh
make dse SIM_SUMMARY=build/实际的仿真目录/summary.json DSE_ARGS='--name baseline'
```

也可直接运行：

```sh
python3 dse/dse.py run --name baseline --sim-summary build/实际的仿真目录/summary.json
```

入口检查该结果是否完整通过 56 例，且与当前 RTL、测试程序和 testbench 一致。修改了代码或测试环境后，旧结果不能继续使用。未传 `--sim-summary` 时仍可测面积，但不合并 CPI，也不标记为可比较配置。

新增硬件源文件时，将相对 `lab2_1` 的路径加入 `dse/rtl.f`。仿真和综合共同读取该清单；不要加入 testbench。配置名称只用于标记结果，不改变电路；探索不同架构时直接修改自己的 RTL，并分别保存测量结果。

## 2. 统一比较条件

| 项目 | 设置 |
|---|---|
| 工具 | Cadence Genus，generic/map/opt 均为 medium，最多 2 CPU |
| 库及角落 | GPDK045 教学库，typical、1.2 V、25°C |
| 时钟 | 30 ns 理想时钟，所有配置保持相同 |
| 外部接口 | 输入/输出延迟各 1 ns；输入 transition 0.1 ns；每个输出位负载 0.01 pF |
| 面积 | CPU 核标准单元 `Cell Area`，单位 µm² |

综合边界是固定的 `dse/core_area.v`：包含 CPU 计算、控制以及实际使用的寄存器文件和指令缓存逻辑，不含 testbench 的外部内存。

首次综合会自动生成 `build/dse/lib/aiarch_lab2_1.lib`，后续校验并复用；不会修改原始 PDK。也可运行 `make dse-lib` 提前准备。

## 3. 查看与比较

每次运行保存在 `build/dse/runs/` 下的新目录：

- `summary.json` / `summary.csv`：面积、单元数、时序及关联的平均 CPI。
- `area.rpt` / `timing.rpt`：原始面积与最差路径报告。
- `genus.log`：综合日志；`mapped.v` / `mapped.sdc`：综合网表和约束。
- `run_manifest.json`、源文件快照及 `simulation_summary.json`：本次配置和验证依据。

每个 case 的 CPI 按 README 中的统一周期与指令计数规则计算。全套指标为 **56 个 case 的 CPI 算术平均**：

```text
平均 CPI = (CPI_1 + CPI_2 + ... + CPI_56) / 56
```

每个 case 等权，不采用“总周期 ÷ 总指令数”。单例调试或部分测试通过不产生可用于比较的平均 CPI。

比较各配置的 **面积、平均 CPI**，两项越小越好。另一个配置两项都不大于当前配置、且至少一项更小时，当前配置被支配；未被支配的配置组成采样范围内的 Pareto 前沿。

仅将 `eligible=true` 的结果纳入比较，即相同实现通过全部 56 例且 `timing_met=true`。时序违例时入口仍保存报告，`timing_met=false`、`eligible=false`；不能只看工具退出码。不同配置的 `comparison_fingerprint` 和 `validation_fingerprint` 应分别一致，以确保库、综合边界、约束和测试环境相同。
