#!/usr/bin/env python3
"""Compile once, run the unchanged 56-program suite, and measure mean CPI."""
import argparse
import csv
from datetime import datetime, timezone
import difflib
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid

from common import file_hash, load_design, load_validation_inputs

ROOT = Path(__file__).resolve().parents[1]
STOP_CODES = {'HALT instruction': 2, 'illegal instruction': 3, 'memory error': 1}


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def run_command(command, cwd, logfile, timeout):
    """Keep tool output in one log and terminate the whole timed-out process group."""
    with logfile.open('w', encoding='utf-8') as log:
        log.write('COMMAND: ' + repr(command) + '\n')
        log.flush()
        process = subprocess.Popen(command, cwd=str(cwd), stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=(os.name == 'posix'))
        try:
            return process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            if os.name == 'posix':
                os.killpg(process.pid, signal.SIGKILL)
            else:
                process.kill()
            process.wait()
            raise ValueError('Wall-clock timeout after {} seconds; inspect {}'.format(timeout, logfile))


def trace_records(path):
    records = []
    for line in path.read_text(encoding='utf-8', errors='replace').splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        match = re.fullmatch(r'PC=([0-9a-fA-F]{16}), (?:---|REG\[\s*(\d+)\]=([0-9a-fA-F]{16}))', line)
        if not match:
            raise ValueError('Malformed commit record in ' + str(path))
        pc, index, data = match.groups()
        records.append((int(pc, 16), None if index is None else int(index),
                        None if data is None else int(data, 16)))
    if not records:
        raise ValueError('No commit records in ' + str(path))
    return records


def memory_records(path):
    text = path.read_text(encoding='utf-8', errors='replace')
    if not text.startswith('@@@ Unified Memory contents'):
        raise ValueError('Missing memory dump header in ' + str(path))
    records = []
    for line in text.splitlines()[1:]:
        if not line.strip() or line.strip() == '@@@':
            continue
        match = re.fullmatch(r'@@@ mem\[\s*(\d+)\] = ([0-9a-fA-F]{16}) : (-?\d+)', line)
        if not match:
            raise ValueError('Malformed memory record in ' + str(path))
        address, data, decimal = match.groups()
        if int(decimal) != int(data, 16):
            raise ValueError('Inconsistent memory decimal/hex fields in ' + str(path))
        records.append((int(address), int(data, 16)))
    return records


def expected_case(source):
    golden = ROOT / 'golden_result'
    text = (golden / (source.name + '_program.out')).read_text(encoding='utf-8', errors='replace')
    stops = re.findall(r'@@@ System halted on (.+)', text)
    if len(stops) != 1 or stops[0] not in STOP_CODES:
        raise ValueError('Cannot determine expected terminal status for ' + source.name)
    image = source.with_suffix('.mem')
    if not image.is_file() or not image.stat().st_size:
        raise ValueError('Missing preassembled program image: ' + str(image))
    if not all(re.fullmatch(r'[0-9a-fA-F]{16}', line) for line in image.read_text().splitlines()):
        raise ValueError('Invalid program image: ' + str(image))
    return {'terminal_status': STOP_CODES[stops[0]],
            'trace': trace_records(golden / (source.name + '_writeback.out')),
            'memory': memory_records(golden / (source.name + '_memory.out'))}


def compile_design(args, out, design):
    folder = out / 'compile'
    folder.mkdir()
    snapshots = folder / 'inputs'
    for record in design['input_files']:
        source = ROOT / record['path']
        target = snapshots / record['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        data = source.read_bytes()
        target.write_bytes(data)
        if file_hash(target) != record['sha256']:
            raise ValueError('Design changed while taking snapshot: ' + record['path'])
    for name in ['testbench/testbench.sv', 'testbench/mem.v']:
        target = snapshots / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((ROOT / name).read_bytes())
    sources = [snapshots / 'sys_defs.vh']
    sources.extend(snapshots / p.relative_to(ROOT) for p in design['rtl_files'])
    sources.extend([snapshots / 'testbench/mem.v', snapshots / 'testbench/testbench.sv'])
    unit = folder / 'compile_unit.sv'
    unit.write_text(''.join('`include "' + p.as_posix().replace('"', '\\"') + '"\n' for p in sources), encoding='utf-8')
    incdirs = ['+incdir+' + str(snapshots / p.relative_to(ROOT)) for p in design['include_dirs']]
    if args.simulator == 'vcs':
        tool = shutil.which('vcs')
        if not tool:
            raise ValueError('Cannot find VCS; first source /etc/profile.d/eda.sh')
        command = [tool, '-full64', '-sverilog', '-top', 'testbench'] + incdirs
        if args.waves:
            command.append('-debug_access+all')
        command.extend([str(unit), '-Mdir=' + str(folder / 'csrc'), '-o', str(folder / 'simv'),
                        '-l', str(folder / 'compile.log')])
    else:
        tool = shutil.which('xrun')
        if not tool:
            raise ValueError('Cannot find Xcelium; first source /etc/profile.d/eda.sh')
        command = [tool, '-64bit', '-sv', '-elaborate', '-top', 'testbench', '-snapshot', 'lab2_1_tb',
                   '-xmlibdirname', str(folder / 'xcelium.d'), '-l', str(folder / 'compile.log')]
        if args.waves:
            command.extend(['-access', '+r'])
        command.extend(incdirs + [str(unit)])
    rc = run_command(command, folder, folder / 'console.log', args.compile_timeout)
    if rc:
        raise ValueError('Compilation failed (exit {}); inspect {}'.format(rc, folder / 'console.log'))
    return folder


def run_case(args, out, compiled, source, expected):
    folder = out / 'cases' / source.stem
    folder.mkdir(parents=True)
    shutil.copyfile(source.with_suffix('.mem'), folder / 'program.mem')
    row = {'case': source.name, 'status': 'FAIL', 'passed': False, 'cycles': None,
           'instructions': None, 'cpi': None, 'terminal_status': None,
           'expected_terminal_status': expected['terminal_status'], 'directory': str(folder)}
    try:
        if args.simulator == 'vcs':
            command = [str(compiled / 'simv'), '-l', 'sim.log']
        else:
            command = [shutil.which('xrun'), '-64bit', '-R', '-snapshot', 'lab2_1_tb',
                       '-xmlibdirname', str(compiled / 'xcelium.d'), '-l', 'sim.log']
        command.extend(['+program=program.mem', '+max_cycles=' + str(args.max_cycles)])
        if args.waves:
            command.append('+waves')
        rc = run_command(command, folder, folder / 'console.log', args.timeout)
        row['simulator_exit_code'] = rc
        if rc:
            raise ValueError('Simulation failed (exit {}); inspect console.log'.format(rc))
        for name in ['metrics.json', 'writeback.out', 'memory.out']:
            if not (folder / name).is_file() or not (folder / name).stat().st_size:
                raise ValueError('Missing or empty simulator output: ' + name)
        metrics = json.loads((folder / 'metrics.json').read_text(encoding='utf-8'))
        for key in ['cycles', 'instructions', 'terminal_status']:
            value = metrics.get(key)
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                raise ValueError('Invalid simulation metric: ' + key)
            row[key] = value
        if not 1 <= row['cycles'] <= args.max_cycles:
            raise ValueError('Invalid cycle count')
        if row['terminal_status'] != expected['terminal_status']:
            raise ValueError('Wrong terminal status: expected {}, got {}'.format(
                expected['terminal_status'], row['terminal_status']))
        actual_trace = trace_records(folder / 'writeback.out')
        if actual_trace != expected['trace']:
            diff = difflib.unified_diff([repr(x)+'\n' for x in expected['trace']],
                                        [repr(x)+'\n' for x in actual_trace],
                                        fromfile='golden commits', tofile='actual commits')
            (folder / 'commit.diff').write_text(''.join(diff), encoding='utf-8')
            raise ValueError('Commit trace mismatch; inspect commit.diff')
        if row['instructions'] != len(expected['trace']) or row['instructions'] <= 0:
            raise ValueError('Instruction count does not match the checked commit trace')
        actual_memory = memory_records(folder / 'memory.out')
        if actual_memory != expected['memory']:
            diff = difflib.unified_diff([repr(x)+'\n' for x in expected['memory']],
                                        [repr(x)+'\n' for x in actual_memory],
                                        fromfile='golden memory', tofile='actual memory')
            (folder / 'memory.diff').write_text(''.join(diff), encoding='utf-8')
            raise ValueError('Final memory mismatch; inspect memory.diff')
        if args.waves and (not (folder / 'pipeline.vcd').is_file() or
                           not (folder / 'pipeline.vcd').stat().st_size):
            raise ValueError('Requested VCD was not generated')
        row['cpi'] = row['cycles'] / row['instructions']
        row.update(status='PASS', passed=True)
    except (OSError, ValueError, RuntimeError) as error:
        row['error'] = str(error)
    write_json(folder / 'result.json', row)
    return row


def save_summary(out, summary):
    write_json(out / 'summary.json', summary)
    fields = ['case', 'status', 'cycles', 'instructions', 'cpi',
              'terminal_status', 'expected_terminal_status', 'error']
    with (out / 'cases.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(summary['cases'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--simulator', choices=['vcs', 'xrun'], default='vcs')
    parser.add_argument('--case', action='append', default=[], metavar='PROGRAM')
    parser.add_argument('--waves', action='store_true')
    parser.add_argument('--name', default='baseline')
    parser.add_argument('--max-cycles', type=int, default=2000000)
    parser.add_argument('--timeout', type=float, default=60)
    parser.add_argument('--compile-timeout', type=float, default=300)
    parser.add_argument('--rtl-filelist', default='dse/rtl.f')
    args = parser.parse_args()
    try:
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}', args.name):
            raise ValueError('Invalid run name')
        if args.max_cycles <= 0 or args.timeout <= 0 or args.compile_timeout <= 0:
            raise ValueError('Cycle and wall-clock time limits must be positive')
        programs = sorted((ROOT / 'test_progs').glob('*.s'))
        if len(programs) != 56:
            raise ValueError('Expected the unchanged suite of 56 assembly programs')
        by_name = {p.name: p for p in programs}
        selected = []
        for name in args.case:
            name = name if name.endswith('.s') else name + '.s'
            if name not in by_name:
                raise ValueError('Unknown CASE: ' + name)
            if by_name[name] not in selected:
                selected.append(by_name[name])
        if not selected:
            selected = programs
        expected = {p.name: expected_case(p) for p in selected}
        design = load_design(ROOT, args.rtl_filelist)
        validation = load_validation_inputs(ROOT)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        out = ROOT / 'build' / 'sim' / args.simulator / (args.name+'_'+stamp+'_'+uuid.uuid4().hex[:8])
        out.mkdir(parents=True)
        summary = {'schema_version': 1, 'simulator': args.simulator,
                   'created_utc': stamp, 'run_directory': str(out),
                   'selected_cases': [p.name for p in selected], 'test_count': len(selected),
                   'full_suite': len(selected) == 56, 'all_passed': False,
                   'all_cases_passed': False, 'eligible_for_comparison': False,
                   'mean_cpi': None, 'cases': [],
                   'cpi_metric': 'arithmetic mean of the 56 individual case CPIs',
                   'instruction_count_rule': 'one per checked commit record; HALT included; illegal instruction excluded',
                   'cycle_count_rule': 'rising edges from first edge after reset release through terminal report, inclusive',
                   'clock_period_ns': 5.0, 'memory_latency_cycles': 4,
                   'max_cycles': args.max_cycles,
                   'rtl_fingerprint': design['rtl_fingerprint'],
                   'input_files': design['input_files']}
        summary.update(validation)
        print('Run directory: ' + str(out), flush=True)
        save_summary(out, summary)
        try:
            compiled = compile_design(args, out, design)
            for source in selected:
                row = run_case(args, out, compiled, source, expected[source.name])
                summary['cases'].append(row)
                if row['passed']:
                    print('[PASS] {} cycles={} instructions={} CPI={:.6f}'.format(
                        source.name, row['cycles'], row['instructions'], row['cpi']), flush=True)
                else:
                    print('[FAIL] {}: {}'.format(source.name, row.get('error', 'unknown error')), flush=True)
                save_summary(out, summary)
            if load_design(ROOT, args.rtl_filelist)['rtl_fingerprint'] != design['rtl_fingerprint']:
                raise ValueError('Design files changed during the run; rerun the tests')
            if load_validation_inputs(ROOT)['validation_fingerprint'] != validation['validation_fingerprint']:
                raise ValueError('Validation inputs changed during the run; rerun the tests')
            summary['all_passed'] = summary['all_cases_passed'] = all(r['passed'] for r in summary['cases'])
            summary['eligible_for_comparison'] = summary['full_suite'] and summary['all_passed']
            if summary['eligible_for_comparison']:
                summary['mean_cpi'] = math.fsum(r['cpi'] for r in summary['cases']) / 56
        except (OSError, ValueError, RuntimeError) as error:
            summary['error'] = str(error)
            print('Tests failed: ' + str(error), file=sys.stderr)
        save_summary(out, summary)
        passed = sum(r['passed'] for r in summary['cases'])
        if summary['eligible_for_comparison']:
            print('ALL TEST CASES PASSED (56/56)')
            print('Mean CPI (56 equally weighted cases): {:.9f}'.format(summary['mean_cpi']))
        elif summary['all_passed']:
            print('SELECTED TEST CASES PASSED ({}/{})'.format(passed, len(selected)))
            print('Run the full suite to obtain the comparable 56-case mean CPI.')
        else:
            print('TEST CASES FAILED ({}/{} passed)'.format(passed, len(selected)))
        print('Summary: ' + str(out / 'summary.json'))
        return 0 if summary['all_passed'] else 1
    except (OSError, ValueError, RuntimeError) as error:
        print('Tests failed: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
