"""Shared RTL discovery and fingerprints for simulation and synthesis."""
import hashlib
import json
from pathlib import Path


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_design(root, filelist='dse/rtl.f'):
    """Return absolute Paths plus stable, relative-path input hash records.

    Keys: root, filelist, rtl_files, include_dirs, input_files, rtl_fingerprint.
    input_files contains dictionaries with POSIX path and sha256 fields.
    The fingerprint hashes canonical JSON of the sorted input_files list.
    """
    root = Path(root).resolve()

    def inside(value):
        path = Path(value)
        path = (root / path).resolve() if not path.is_absolute() else path.resolve()
        try:
            path.relative_to(root)
        except ValueError:
            raise ValueError('Design paths must stay inside lab2_1: ' + str(value))
        return path

    listing = inside(filelist)
    rtl = []
    listed_inputs = []
    dependencies = {listing}
    for line in listing.read_text(encoding='utf-8').splitlines():
        value = line.strip()
        if not value or value.startswith(('#', '//')):
            continue
        path = inside(value)
        if not path.is_file() or path.suffix.lower() not in {'.v', '.sv', '.vh', '.svh'}:
            raise ValueError('Expected a Verilog source/header: ' + value)
        if 'testbench' in path.parts or path.name.endswith(('_tb.v', '_tb.sv')):
            raise ValueError('Do not put the testbench in the hardware file list')
        dependencies.add(path)
        if path not in listed_inputs:
            listed_inputs.append(path)
        if path.suffix.lower() in {'.v', '.sv'} and path not in rtl:
            rtl.append(path)
    if not rtl:
        raise ValueError('The RTL file list is empty')
    includes = [root]
    # Explicitly listed headers may live outside every RTL source directory.
    # Their parents must be searchable too. Only declared source/header parents
    # are traversed; the root remains shallow to exclude build/ snapshots.
    for path in listed_inputs:
        if path.parent not in includes:
            includes.append(path.parent)
    for directory in includes:
        # Root headers are shallow so build/ snapshots are never recaptured.
        candidates = directory.iterdir() if directory == root else directory.rglob('*')
        for path in candidates:
            if path.is_file() and path.suffix.lower() in {'.vh', '.svh'}:
                dependencies.add(inside(path))
    defs = root / 'sys_defs.vh'
    if not defs.is_file():
        raise ValueError('Missing sys_defs.vh')
    dependencies.add(defs)
    records = [{'path': p.relative_to(root).as_posix(), 'sha256': file_hash(p)}
               for p in sorted(dependencies, key=lambda p: p.relative_to(root).as_posix())]
    canonical = json.dumps(records, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return {'root': root, 'filelist': listing, 'rtl_files': rtl,
            'include_dirs': includes, 'input_files': records,
            'rtl_fingerprint': hashlib.sha256(canonical).hexdigest()}


def load_validation_inputs(root):
    """Fingerprint the fixed full suite, checker and memory model."""
    root = Path(root).resolve()
    programs = sorted((root / 'test_progs').glob('*.s'))
    if len(programs) != 56:
        raise ValueError('Expected the unchanged suite of 56 assembly programs')
    paths = [root / name for name in [
        'testbench/testbench.sv', 'testbench/mem.v',
        'run/run_tests.py', 'run/common.py']]
    for source in programs:
        paths.extend([source, source.with_suffix('.mem')])
        for suffix in ['writeback.out', 'memory.out', 'program.out']:
            paths.append(root / 'golden_result' / (source.name + '_' + suffix))
    records = []
    for path in sorted(paths, key=lambda p: p.relative_to(root).as_posix()):
        if not path.is_file():
            raise ValueError('Missing validation input: ' + str(path.relative_to(root)))
        records.append({'path': path.relative_to(root).as_posix(), 'sha256': file_hash(path)})
    canonical = json.dumps(records, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return {'validation_inputs': records,
            'validation_fingerprint': hashlib.sha256(canonical).hexdigest()}
