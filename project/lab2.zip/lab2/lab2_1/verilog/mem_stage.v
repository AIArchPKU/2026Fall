`timescale 1ns/100ps
`default_nettype none

// Implement this module with synthesizable RTL.
module mem_stage (
    input wire clock,
    input wire reset,
    input wire [63:0] ex_mem_rega,
    input wire [63:0] ex_mem_alu_result,
    input wire ex_mem_rd_mem,
    input wire ex_mem_wr_mem,
    input wire [63:0] Dmem2proc_data,
    input wire [3:0] Dmem2proc_tag,
    input wire [3:0] Dmem2proc_response,
    output wire [63:0] mem_result_out,
    output wire mem_stall_out,
    output wire [1:0] proc2Dmem_command,
    output wire [63:0] proc2Dmem_addr,
    output wire [63:0] proc2Dmem_data
);

    // TODO: generate and implement the module internals.

endmodule

`default_nettype wire
