`timescale 1ns/100ps
`default_nettype none

// Implement this module with synthesizable RTL.
module wb_stage (
    input wire clock,
    input wire reset,
    input wire [63:0] mem_wb_NPC,
    input wire [63:0] mem_wb_result,
    input wire mem_wb_take_branch,
    input wire [4:0] mem_wb_dest_reg_idx,
    input wire mem_wb_valid_inst,
    output wire [63:0] reg_wr_data_out,
    output wire [4:0] reg_wr_idx_out,
    output wire reg_wr_en_out
);

    // TODO: generate and implement the module internals.

endmodule

`default_nettype wire
