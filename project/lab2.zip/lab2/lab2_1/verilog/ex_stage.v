`timescale 1ns/100ps
`default_nettype none

// Implement this module with synthesizable RTL.
module ex_stage (
    input wire clock,
    input wire reset,
    input wire [63:0] id_ex_NPC,
    input wire [31:0] id_ex_IR,
    input wire [63:0] id_ex_rega,
    input wire [63:0] id_ex_regb,
    input wire [1:0] id_ex_opa_select,
    input wire [1:0] id_ex_opb_select,
    input wire [4:0] id_ex_alu_func,
    input wire id_ex_cond_branch,
    input wire id_ex_uncond_branch,
    output wire [63:0] ex_alu_result_out,
    output wire ex_take_branch_out
);

    // TODO: generate and implement the module internals.

endmodule

`default_nettype wire
