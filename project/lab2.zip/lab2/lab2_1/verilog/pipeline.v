`timescale 1ns/100ps
`default_nettype none

// Implement this module with synthesizable RTL.
module pipeline (
    input wire clock,
    input wire reset,
    input wire [3:0] mem2proc_response,
    input wire [63:0] mem2proc_data,
    input wire [3:0] mem2proc_tag,
    output wire [1:0] proc2mem_command,
    output wire [63:0] proc2mem_addr,
    output wire [63:0] proc2mem_data,
    output wire [3:0] pipeline_completed_insts,
    output wire [3:0] pipeline_error_status,
    output wire [63:0] pipeline_commit_wr_data,
    output wire [4:0] pipeline_commit_wr_idx,
    output wire pipeline_commit_wr_en,
    output wire [63:0] pipeline_commit_NPC,
    output wire [63:0] if_NPC_out,
    output wire [31:0] if_IR_out,
    output wire if_valid_inst_out,
    output wire [63:0] if_id_NPC,
    output wire [31:0] if_id_IR,
    output wire if_id_valid_inst,
    output wire [63:0] id_ex_NPC,
    output wire [31:0] id_ex_IR,
    output wire id_ex_valid_inst,
    output wire [63:0] ex_mem_NPC,
    output wire [31:0] ex_mem_IR,
    output wire ex_mem_valid_inst,
    output wire [63:0] mem_wb_NPC,
    output wire [31:0] mem_wb_IR,
    output wire mem_wb_valid_inst
);

    // TODO: generate and implement the module internals.

endmodule

`default_nettype wire
