`timescale 1ns/100ps
`default_nettype none

// Implement this module with synthesizable RTL.
module id_stage (
    input wire clock,
    input wire reset,
    input wire [31:0] if_id_IR,
    input wire if_id_valid_inst,
    input wire wb_reg_wr_en_out,
    input wire [4:0] wb_reg_wr_idx_out,
    input wire [63:0] wb_reg_wr_data_out,
    output wire [63:0] id_ra_value_out,
    output wire [63:0] id_rb_value_out,
    output wire [1:0] id_opa_select_out,
    output wire [1:0] id_opb_select_out,
    output wire [4:0] id_dest_reg_idx_out,
    output wire [4:0] id_alu_func_out,
    output wire id_rd_mem_out,
    output wire id_wr_mem_out,
    output wire id_ldl_mem_out,
    output wire id_stc_mem_out,
    output wire id_cond_branch_out,
    output wire id_uncond_branch_out,
    output wire id_halt_out,
    output wire id_cpuid_out,
    output wire id_illegal_out,
    output wire id_valid_inst_out
);

    // TODO: generate and implement the module internals.

endmodule

`default_nettype wire
