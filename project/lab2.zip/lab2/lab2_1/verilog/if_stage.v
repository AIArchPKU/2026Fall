`timescale 1ns/100ps
`default_nettype none

// Implement this module with synthesizable RTL.
module if_stage (
    input wire clock,
    input wire reset,
    input wire mem_wb_valid_inst,
    input wire ex_mem_take_branch,
    input wire [63:0] ex_mem_target_pc,
    input wire [63:0] Imem2proc_data,
    input wire Imem_valid,
    output wire [63:0] if_NPC_out,
    output wire [31:0] if_IR_out,
    output wire [63:0] proc2Imem_addr,
    output wire if_valid_inst_out
);

    // TODO: generate and implement the module internals.

endmodule

`default_nettype wire
