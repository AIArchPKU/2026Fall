# Lab 2-1：用 AI 生成并优化 CPU

用 AI 实现 `verilog/` 中以下六个模块。模板只保留 IO，内部硬件由你设计；在通过全部测试后，探索标准单元面积与 CPI 的取舍。

```text
if_stage.v    id_stage.v    ex_stage.v
mem_stage.v   wb_stage.v    pipeline.v
```

可以采用单指令在途、流水线、前馈或其他实现，不限定内部复杂度。保留顶层模块 `pipeline` 的端口及其含义；内部阶段可以增加控制端口和辅助模块，新增 RTL 文件须加入 dse/rtl.f，仿真和综合均读取该清单。各阶段调试端口按所选微架构提供观察信息，不参与正确性判定；提交接口必须保持规定的含义。

本次lab使用 Alpha 教学指令子集：32 位指令、64 位数据与地址、32 个 64 位寄存器，`r31` 恒为零。以随包 `sys_defs.vh` 中的编码及测试程序为准，不要求实现该头文件列出的全部扩展指令。

支持的主要指令包括整数加减、乘法、逻辑、移位、比较、`LDA/LDQ/STQ`、整数条件分支、`BR/BSR/JMP/JSR/RET` 和 `call_pal` 停止。运算保留 64 位结果；ALU literal 零扩展 8 位，访存位移符号扩展 16 位，分支位移符号扩展 21 位后左移 2 位。顺序取指时PC每次递增 4，外部存储器按 8 字节对齐访问。

保留并使用给定的 `regfile.v`、`icache.v`、`cachemem.v`；不要修改支持模块、指令定义、存储器模型、公开测试或golden_result。外部存储器固定为 64 KiB、原模型 4 周期延迟。复位后从 PC=0 执行。`pipeline_commit_NPC` 报告提交指令的 PC+4，`pipeline_completed_insts` 为 0 或 1；寄存器写回使用配套的 index/data/enable 端口。HALT 应作为一条提交指令报告，再停止；非法指令不提交，用 `pipeline_error_status` 报告。

存储器请求被接受时，`mem2proc_response` 给出非零事务标签；读数据随后通过 `mem2proc_tag` 携带匹配标签返回。请求被接受不代表读数据已经返回，具体握手见 `testbench/mem.v`。

## 运行与调试

在 xLab 的 Linux 终端进入本目录：

```sh
source /etc/profile.d/eda.sh
make test
```

默认使用 VCS；也可使用 `make xrun`。测试入口只编译一次，再逐项运行原有 **56 个程序**，比较按序提交的 PC/寄存器写回记录、最终内存和预期结束状态。通过全部测试时输出 `ALL TEST CASES PASSED (56/56)`；任何失败、缺失结果或超时都会返回失败。初始空模板不能通过测试。

```sh
make test CASE=00-halt
make test CASE=04-branch WAVES=1
make xrun CASE=04-branch WAVES=1
```

每次运行在 `build/` 下保存独立目录，内含编译日志、各程序仿真日志、差异文件及 JSON/CSV 汇总。`WAVES=1` 生成 VCD；用例名支持带或不带 `.s` 后缀。单例通过仅用于调试，不能代替 56 个程序全量通过。

多数程序以 HALT 结束；部分程序的原 golden_result 预期为非法指令结束，入口按各自预期验收。

原始汇编 `.s` 的 golden_result 保持不变；随包提供对应的 `.mem`，正常测试无需安装或运行汇编器。如要重新汇编，可在 xLab 执行：

```sh
python3 tools/assemble.py
# 汇编自己编写的程序：
python3 tools/assemble.py path/to/custom.s --output path/to/custom.mem
```

## 面积与 CPI

每个程序的 `CPI = cycles / instructions`。`cycles` 从复位释放后的第一个上升沿统计到报告结束状态的上升沿；`instructions` 是与 golden_result 一致的提交记录条数，包含 HALT，不包含引发非法指令结束的指令。因此只有 HALT 的程序也有 1 条指令。

比较指标为 56 个程序各自 CPI 的算术平均 ：

```text
mean_CPI = (CPI_1 + CPI_2 + ... + CPI_56) / 56
```

每个程序等权，不按程序长度加权。只有全部 56 个程序通过才产生可用于比较的 `mean_cpi`。单指令、流水级数、前馈、冒险处理、控制或运算结构等均可作为设计探索变量；所有配置使用同一测试集和外部环境。

设计空间探索不要求穷举所有微架构或参数组合，也不要求把上述方向全部实现。挑选几个自己感兴趣的方案或配置比较，说明面积与性能变化的原因及取舍即可。

面积测试与结果关联方式见 [DSE_AREA.md](DSE_AREA.md)。统一综合约束为 30 ns 理想时钟；只比较功能全部通过且满足该时序目标的配置。面积为完整 CPU 核的标准单元面积，包含给定寄存器文件和指令缓存，不包含外部存储器模型。面积和平均 CPI 均越小越好；没有其他有效配置同时不大于两项且至少一项更小时，该配置属于本次候选中的 Pareto 前沿。

提交实现的六个模块、所需辅助 RTL/头文件和更新后的 `dse/rtl.f`，以及对应全量测试和面积/CPI 汇总结果。每组配置保留对应源码或可复现参数、完整仿真 `summary.json`、综合 `summary.json`/`summary.csv` 和 `run_manifest.json`。报告和打包要求见上一级 `README.md`。
