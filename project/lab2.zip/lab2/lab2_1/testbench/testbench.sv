`timescale 1ns/100ps

// Acceptance uses only the public CPU interface and the external memory model.
// Stage debug ports may describe any student microarchitecture; they are not
// used to decide correctness. One commit record can be emitted per clock.
module testbench;
  reg clock = 0;
  reg reset = 1;
  integer cycle_count = 0;
  integer instruction_count = 0;
  integer max_cycles = 2000000;
  integer wb_fileno, mem_fileno, metrics_fileno, pipe_fileno;
  reg [8*512-1:0] program_path;

  wire [1:0]  proc2mem_command;
  wire [63:0] proc2mem_addr;
  wire [63:0] proc2mem_data;
  wire [3:0]  mem2proc_response;
  wire [63:0] mem2proc_data;
  wire [3:0]  mem2proc_tag;

  wire [3:0]  pipeline_completed_insts;
  wire [3:0]  pipeline_error_status;
  wire [4:0]  pipeline_commit_wr_idx;
  wire [63:0] pipeline_commit_wr_data;
  wire        pipeline_commit_wr_en;
  wire [63:0] pipeline_commit_NPC;


  wire [63:0] if_NPC_out;
  wire [31:0] if_IR_out;
  wire        if_valid_inst_out;
  wire [63:0] if_id_NPC;
  wire [31:0] if_id_IR;
  wire        if_id_valid_inst;
  wire [63:0] id_ex_NPC;
  wire [31:0] id_ex_IR;
  wire        id_ex_valid_inst;
  wire [63:0] ex_mem_NPC;
  wire [31:0] ex_mem_IR;
  wire        ex_mem_valid_inst;
  wire [63:0] mem_wb_NPC;
  wire [31:0] mem_wb_IR;
  wire        mem_wb_valid_inst;

  // Instantiate the Pipeline
  pipeline pipeline_0 (// Inputs
                       .clock             (clock),
                       .reset             (reset),
                       .mem2proc_response (mem2proc_response),
                       .mem2proc_data     (mem2proc_data),
                       .mem2proc_tag      (mem2proc_tag),

                        // Outputs
                       .proc2mem_command  (proc2mem_command),
                       .proc2mem_addr     (proc2mem_addr),
                       .proc2mem_data     (proc2mem_data),

                       .pipeline_completed_insts(pipeline_completed_insts),
                       .pipeline_error_status(pipeline_error_status),
                       .pipeline_commit_wr_data(pipeline_commit_wr_data),
                       .pipeline_commit_wr_idx(pipeline_commit_wr_idx),
                       .pipeline_commit_wr_en(pipeline_commit_wr_en),
                       .pipeline_commit_NPC(pipeline_commit_NPC),

                       .if_NPC_out(if_NPC_out),
                       .if_IR_out(if_IR_out),
                       .if_valid_inst_out(if_valid_inst_out),
                       .if_id_NPC(if_id_NPC),
                       .if_id_IR(if_id_IR),
                       .if_id_valid_inst(if_id_valid_inst),
                       .id_ex_NPC(id_ex_NPC),
                       .id_ex_IR(id_ex_IR),
                       .id_ex_valid_inst(id_ex_valid_inst),
                       .ex_mem_NPC(ex_mem_NPC),
                       .ex_mem_IR(ex_mem_IR),
                       .ex_mem_valid_inst(ex_mem_valid_inst),
                       .mem_wb_NPC(mem_wb_NPC),
                       .mem_wb_IR(mem_wb_IR),
                       .mem_wb_valid_inst(mem_wb_valid_inst)
                      );


  // Instantiate the Data Memory
  mem memory (// Inputs
            .clk               (clock),
            .proc2mem_command  (proc2mem_command),
            .proc2mem_addr     (proc2mem_addr),
            .proc2mem_data     (proc2mem_data),

             // Outputs

            .mem2proc_response (mem2proc_response),
            .mem2proc_data     (mem2proc_data),
            .mem2proc_tag      (mem2proc_tag)
           );

  always #(`VERILOG_CLOCK_PERIOD/2.0) clock = ~clock;

  // Count the first rising edge after reset release as cycle 1. The monitor
  // samples that edge's public outputs at the following falling edge + 2 ns,
  // after the supplied modules' #1 nonblocking updates have settled.
  always @(posedge clock)
    if (reset) cycle_count = 0;
    else cycle_count = cycle_count + 1;

  initial begin
    program_path = "program.mem";
    if ($value$plusargs("program=%s", program_path)) begin end
    if ($value$plusargs("max_cycles=%d", max_cycles)) begin end
    if (max_cycles <= 0) $fatal(1, "max_cycles must be positive");
    if ($test$plusargs("waves")) begin
      $dumpfile("pipeline.vcd");
      $dumpvars(0, pipeline_0);
    end
    repeat (2) @(posedge clock);
    $readmemh(program_path, memory.unified_memory);
    repeat (2) @(posedge clock);
    #1;
    wb_fileno = $fopen("writeback.out", "w");
    pipe_fileno = $fopen("pipeline.out", "w");
    if (!wb_fileno || !pipe_fileno) $fatal(1, "Cannot open trace files");
    $fdisplay(pipe_fileno, "# cycle IF_IR IF_valid ID_IR ID_valid EX_IR EX_valid MEM_IR MEM_valid WB_IR WB_valid");
    reset = 0;
  end

  task automatic dump_memory;
    integer k, showing_data;
    begin
      mem_fileno = $fopen("memory.out", "w");
      if (!mem_fileno) $fatal(1, "Cannot open memory.out");
      $fdisplay(mem_fileno, "@@@ Unified Memory contents hex on left, decimal on right: ");
      $fdisplay(mem_fileno, "@@@");
      showing_data = 0;
      for (k = 0; k < `MEM_64BIT_LINES; k = k + 1) begin
        if ($isunknown(memory.unified_memory[k]))
          $fatal(1, "Unknown value in external memory at byte address %0d", k*8);
        if (memory.unified_memory[k] != 0) begin
          $fdisplay(mem_fileno, "@@@ mem[%5d] = %x : %0d", k*8,
                    memory.unified_memory[k], memory.unified_memory[k]);
          showing_data = 1;
        end else if (showing_data != 0) begin
          $fdisplay(mem_fileno, "@@@");
          showing_data = 0;
        end
      end
      $fdisplay(mem_fileno, "@@@");
      $fclose(mem_fileno);
    end
  endtask

  always @(negedge clock) begin
    if (!reset) begin
      #2;
      if (cycle_count > 0) begin
        if ($isunknown(pipeline_completed_insts) || $isunknown(pipeline_error_status))
          $fatal(1, "CPU completion/status contains X/Z; implement and reset the top-level outputs");
        if (pipeline_completed_insts > 1)
          $fatal(1, "The public interface carries at most one commit record per cycle");
        if ($isunknown(proc2mem_command) || proc2mem_command > `BUS_STORE)
          $fatal(1, "Invalid or unknown memory bus command");
        if (proc2mem_command != `BUS_NONE &&
            ($isunknown(proc2mem_addr) || proc2mem_addr[2:0] != 0 ||
             proc2mem_addr >= `MEM_SIZE_IN_BYTES))
          $fatal(1, "Memory request must use an aligned in-range address");
        if (proc2mem_command == `BUS_STORE && $isunknown(proc2mem_data))
          $fatal(1, "Store data contains X/Z");

        $fdisplay(pipe_fileno, "%0d %x %b %x %b %x %b %x %b %x %b", cycle_count,
          if_IR_out, if_valid_inst_out, if_id_IR, if_id_valid_inst,
          id_ex_IR, id_ex_valid_inst, ex_mem_IR, ex_mem_valid_inst,
          mem_wb_IR, mem_wb_valid_inst);
        if (pipeline_completed_insts == 1) begin
          if ($isunknown(pipeline_commit_NPC) || $isunknown(pipeline_commit_wr_en))
            $fatal(1, "Commit PC/enable contains X/Z");
          if (pipeline_commit_wr_en) begin
            if ($isunknown(pipeline_commit_wr_idx) || $isunknown(pipeline_commit_wr_data))
              $fatal(1, "Register writeback contains X/Z");
            $fdisplay(wb_fileno, "PC=%x, REG[%d]=%x", pipeline_commit_NPC-64'd4,
                      pipeline_commit_wr_idx, pipeline_commit_wr_data);
          end else
            $fdisplay(wb_fileno, "PC=%x, ---", pipeline_commit_NPC-64'd4);
          instruction_count = instruction_count + 1;
        end

        if (pipeline_error_status != `NO_ERROR) begin
          dump_memory();
          $fclose(wb_fileno);
          $fclose(pipe_fileno);
          metrics_fileno = $fopen("metrics.json", "w");
          if (!metrics_fileno) $fatal(1, "Cannot open metrics.json");
          $fdisplay(metrics_fileno,
            "{\"cycles\": %0d, \"instructions\": %0d, \"terminal_status\": %0d}",
            cycle_count, instruction_count, pipeline_error_status);
          $fclose(metrics_fileno);
          $display("[RESULT] cycles=%0d instructions=%0d terminal_status=%0d",
                   cycle_count, instruction_count, pipeline_error_status);
          $finish;
        end else if (cycle_count >= max_cycles)
          $fatal(1, "CPU exceeded cycle limit (%0d)", max_cycles);
      end
    end
  end
endmodule

