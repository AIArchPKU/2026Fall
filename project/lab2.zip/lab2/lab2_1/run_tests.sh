#!/usr/bin/env bash
# Prefer make vcs / make xrun. This wrapper also accepts the former -t/-q form.
set -euo pipefail
cd -- "$(dirname -- "$0")"
args=()
while (($#)); do
  case "$1" in
    -q|--quiet) shift ;;
    -t|--test)
      (($# >= 2)) || { echo 'Missing program after -t' >&2; exit 2; }
      args+=(--case "$(basename -- "$2")")
      shift 2 ;;
    *) args+=("$1"); shift ;;
  esac
done
exec python3 run/run_tests.py "${args[@]}"
