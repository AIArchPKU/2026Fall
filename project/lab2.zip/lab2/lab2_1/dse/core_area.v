`timescale 1ns/100ps
`default_nettype none

// Fixed synthesis boundary. Stage debug outputs remain available in simulation
// but do not become physical pins or prevent unused debug logic optimization.
module core_area (
    input  wire        clock,
    input  wire        reset,
    input  wire [3:0]  mem2proc_response,
    input  wire [63:0] mem2proc_data,
    input  wire [3:0]  mem2proc_tag,
    output wire [1:0]  proc2mem_command,
    output wire [63:0] proc2mem_addr,
    output wire [63:0] proc2mem_data,
    output wire [3:0]  pipeline_completed_insts,
    output wire [3:0]  pipeline_error_status,
    output wire [63:0] pipeline_commit_wr_data,
    output wire [4:0]  pipeline_commit_wr_idx,
    output wire        pipeline_commit_wr_en,
    output wire [63:0] pipeline_commit_NPC
);
    pipeline cpu (
        .clock(clock), .reset(reset),
        .mem2proc_response(mem2proc_response),
        .mem2proc_data(mem2proc_data), .mem2proc_tag(mem2proc_tag),
        .proc2mem_command(proc2mem_command), .proc2mem_addr(proc2mem_addr),
        .proc2mem_data(proc2mem_data),
        .pipeline_completed_insts(pipeline_completed_insts),
        .pipeline_error_status(pipeline_error_status),
        .pipeline_commit_wr_data(pipeline_commit_wr_data),
        .pipeline_commit_wr_idx(pipeline_commit_wr_idx),
        .pipeline_commit_wr_en(pipeline_commit_wr_en),
        .pipeline_commit_NPC(pipeline_commit_NPC),
        .if_NPC_out(), .if_IR_out(), .if_valid_inst_out(),
        .if_id_NPC(), .if_id_IR(), .if_id_valid_inst(),
        .id_ex_NPC(), .id_ex_IR(), .id_ex_valid_inst(),
        .ex_mem_NPC(), .ex_mem_IR(), .ex_mem_valid_inst(),
        .mem_wb_NPC(), .mem_wb_IR(), .mem_wb_valid_inst()
    );
endmodule

`default_nettype wire
