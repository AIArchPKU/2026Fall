# DSE_CONFIG is a per-run config created by dse.py.
if {[catch {
    source $::env(DSE_CONFIG)
    set_db max_cpus_per_server 2
    set_db syn_generic_effort medium
    set_db syn_map_effort medium
    set_db syn_opt_effort medium
    set_db hdl_error_on_blackbox true
    set_db library $library_file
    set_db hdl_search_path $include_dirs
    read_hdl -sv $compilation_unit
    elaborate core_area
    read_sdc $constraint_file
    check_design -unresolved > check_design.rpt
    syn_generic
    syn_map
    syn_opt
    check_design -unresolved > check_design_mapped.rpt
    report_area > area.rpt
    report_gates > gates.rpt
    report_timing > timing.rpt
    write_hdl > mapped.v
    write_sdc > mapped.sdc
    puts DSE_AREA_DONE
} reason]} {
    puts stderr "DSE_AREA_FAILED: $reason"
    exit 1
}
exit
