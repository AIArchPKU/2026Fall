create_clock -name core_clock -period 30.0 [get_ports clock]

# Fixed ideal clock, without clock uncertainty, latency or clock-tree modeling.
set data_inputs [remove_from_collection [all_inputs] [get_ports clock]]
set_input_delay 1.0 -clock core_clock $data_inputs
set_output_delay 1.0 -clock core_clock [all_outputs]
set_input_transition 0.1 $data_inputs
set_load 0.01 [all_outputs]
