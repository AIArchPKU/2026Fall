# Hardware sources, relative to lab2_1. Used by both simulation and synthesis.
# Add any new hardware modules or headers here; do not list testbenches.
verilog/pipeline.v
verilog/regfile.v
verilog/icache.v
verilog/if_stage.v
verilog/id_stage.v
verilog/ex_stage.v
verilog/mem_stage.v
verilog/wb_stage.v
verilog/cachemem.v
