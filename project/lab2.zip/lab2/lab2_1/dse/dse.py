#!/usr/bin/env python3
"""Measure Lab 2-1 CPU standard-cell area with the fixed course constraints.

Python 3.6+ and its standard library are sufficient. Genus is required for run.
"""

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid

from dse_lib import prepare_library

LAB_ROOT = Path(__file__).resolve().parents[1]
DSE_ROOT = LAB_ROOT / 'dse'
BUILD_ROOT = LAB_ROOT / 'build' / 'dse'
sys.path.insert(0, str(LAB_ROOT / 'run'))
from common import load_design, load_validation_inputs  # noqa: E402

PDK_ROOT = Path('/opt/eda/Cadence/INNOVUS211/share/FoundationFlows/EXAMPLES/'
                'INNOVUS/DESIGN/GPDK/LIBS/GPDK045')
CONDITIONS = {
    'top': 'core_area', 'corner': 'typical, 1.2 V, 25 C',
    'clock_period_ns': 30.0, 'clock_model': 'ideal',
    'input_delay_ns': 1.0, 'output_delay_ns': 1.0,
    'data_input_transition_ns': 0.1, 'output_load_pf': 0.01,
    'synthesis_effort': 'medium', 'max_cpus': 2,
    'area_unit': 'um^2', 'power_analysis': False,
    'area_boundary': 'CPU hardware, including used register-file/cache logic; '
                     'excludes external memory model and stage debug pins',
}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def object_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'))
                          .encode('utf-8')).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + '\n',
                    encoding='utf-8')


def tcl_string(value):
    value = str(value)
    for old, new in [('\\', '\\\\'), ('"', '\\"'), ('$', '\\$'),
                     ('[', '\\['), (']', '\\]'), ('\n', '\\n'), ('\r', '\\r')]:
        value = value.replace(old, new)
    return '"' + value + '"'


def tcl_list(values):
    return '[list ' + ' '.join(tcl_string(value) for value in values) + ']'


def verilog_include(path):
    value = Path(path).as_posix().replace('"', '\\"')
    if '\n' in value or '\r' in value:
        raise ValueError('Source paths must not contain newlines')
    return '`include "' + value + '"'


def parse_reports(area_text, timing_text):
    module = re.search(r'^\s*Module:\s*(\S+)', area_text, re.M)
    if not module:
        raise ValueError('Cannot find the top module in area.rpt')
    row = re.search(r'^\s*' + re.escape(module.group(1)) +
                    r'\s+(?:\S+\s+)?(\d+)\s+([\d.eE+-]+)\s+'
                    r'([\d.eE+-]+)\s+([\d.eE+-]+)(?:\s|$)', area_text, re.M)
    if not row:
        raise ValueError('Cannot parse the top Cell Area row in area.rpt')
    count, area = int(row.group(1)), float(row.group(2))
    if not math.isfinite(area):
        raise ValueError('Nonfinite cell area in area.rpt')
    metrics = {'mapped_top': module.group(1), 'cell_count': count,
               'cell_area_um2': area, 'worst_slack_ns': None, 'timing_met': None}
    # Empty interface templates have no timed logic. Diagnose the missing
    # hardware before interpreting Genus's version-dependent no-path message.
    if count <= 0 or area <= 0:
        return metrics
    slack = re.search(r'Path\s+1:\s+(MET|VIOLATED)\s+\(([-+\d.eE]+)\s+ps\)',
                      timing_text)
    if slack:
        timing_met = slack.group(1) == 'MET'
        slack_ps = float(slack.group(2))
        if not math.isfinite(slack_ps):
            raise ValueError('Nonfinite slack in timing.rpt')
        if not timing_met:
            slack_ps = -abs(slack_ps)
    elif ('No paths found' in timing_text or
          'Some unconstrained paths have not been displayed.' in timing_text):
        timing_met, slack_ps = None, None
    else:
        raise ValueError('Cannot parse the worst path in timing.rpt')
    metrics.update({'worst_slack_ns': None if slack_ps is None else slack_ps / 1000,
                    'timing_met': timing_met})
    return metrics


def read_simulation(path, design):
    """Attach CPI only when a complete, current validation result is supplied."""
    if path is None:
        return None
    path = Path(path).resolve()
    text = path.read_text(encoding='utf-8')
    result = json.loads(text)
    if not isinstance(result, dict):
        raise ValueError('Simulation summary must be a JSON object')
    if (result.get('schema_version') != 1 or result.get('full_suite') is not True or
            result.get('all_passed') is not True or result.get('test_count') != 56 or
            result.get('eligible_for_comparison') is not True):
        raise ValueError('--sim-summary must be a successful full 56-case result')
    if result.get('rtl_fingerprint') != design['rtl_fingerprint']:
        raise ValueError('RTL changed since the supplied simulation; rerun all 56 tests')
    if result.get('input_files') != design['input_files']:
        raise ValueError('Simulation/synthesis source records do not match')
    validation = load_validation_inputs(LAB_ROOT)
    if result.get('validation_fingerprint') != validation['validation_fingerprint']:
        raise ValueError('Tests or testbench changed since simulation; rerun all 56 tests')
    if result.get('validation_inputs') != validation['validation_inputs']:
        raise ValueError('Simulation validation input records do not match')
    mean = result.get('mean_cpi')
    if isinstance(mean, bool) or not isinstance(mean, (float, int)) or not math.isfinite(mean) or mean <= 0:
        raise ValueError('Simulation mean_cpi must be finite and positive')
    rows = result.get('cases')
    if not isinstance(rows, list) or len(rows) != 56:
        raise ValueError('Simulation must contain 56 per-case results')
    expected_cases = {p.name for p in (LAB_ROOT / 'test_progs').glob('*.s')}
    if {row.get('case') for row in rows if isinstance(row, dict)} != expected_cases:
        raise ValueError('Simulation must contain each of the original 56 cases exactly once')
    cpis = []
    for row in rows:
        if (not isinstance(row, dict) or row.get('passed') is not True or
                row.get('status') != 'PASS'):
            raise ValueError('Every simulation case must pass before attaching CPI')
        cycles, instructions, cpi = row.get('cycles'), row.get('instructions'), row.get('cpi')
        if (type(cycles) is not int or cycles <= 0 or
                type(instructions) is not int or instructions <= 0 or
                isinstance(cpi, bool) or not isinstance(cpi, (float, int)) or
                not math.isfinite(cpi) or cpi <= 0 or
                not math.isclose(cpi, cycles / instructions, rel_tol=1e-12, abs_tol=1e-12)):
            raise ValueError('Invalid per-case cycles, instructions or CPI in simulation summary')
        if (row.get('terminal_status') not in (1, 2, 3) or
                row.get('terminal_status') != row.get('expected_terminal_status')):
            raise ValueError('Simulation terminal status does not match the expected result')
        cpis.append(cpi)
    recomputed = math.fsum(cpis) / 56
    if not math.isclose(mean, recomputed, rel_tol=1e-12, abs_tol=1e-12):
        raise ValueError('mean_cpi must be the arithmetic mean of the 56 per-case CPIs')
    return {'path': str(path), 'sha256': hashlib.sha256(text.encode('utf-8')).hexdigest(),
            'data': result, 'mean_cpi': recomputed}


def summary_files(out, summary):
    write_json(out / 'summary.json', summary)
    fields = ['name', 'status', 'cell_count', 'cell_area_um2', 'worst_slack_ns',
              'timing_met', 'clock_period_ns', 'mean_cpi', 'eligible',
              'rtl_fingerprint', 'comparison_fingerprint', 'run_directory']
    with (out / 'summary.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerow(summary)


def run_area(args):
    executable = shutil.which(args.genus)
    if not executable:
        raise ValueError('Cannot find Genus; run: source /etc/profile.d/eda.sh')
    # Cadence launchers dispatch by basename, so do not dereference the symlink.
    executable = os.path.abspath(executable)
    design = load_design(LAB_ROOT, args.rtl_filelist)
    simulation = read_simulation(args.sim_summary, design)
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}', args.name):
        raise ValueError('Run name must be 1-64 letters, digits, dots, underscores or hyphens')
    library, library_manifest, reused = prepare_library(
        Path(args.liberty), Path(args.lef), BUILD_ROOT / 'lib')
    print(('Reusing' if reused else 'Prepared') + ' library: ' + str(library), flush=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    out = BUILD_ROOT / 'runs' / (args.name + '_' + stamp + '_' + uuid.uuid4().hex[:8])
    out.mkdir(parents=True)
    summary = {'schema_version': 1, 'name': args.name, 'status': 'failed',
               'clock_period_ns': CONDITIONS['clock_period_ns'],
               'rtl_fingerprint': design['rtl_fingerprint'],
               'run_directory': str(out), 'library_reused': reused,
               'mean_cpi': None, 'eligible': False,
               'functional_test': 'not_attached' if simulation is None else 'passed_56_of_56',
               'eligibility_reasons': []}
    print('Run directory: ' + str(out), flush=True)
    try:
        snapshots = []
        for record in design['input_files']:
            target = out / 'inputs' / record['path']
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((LAB_ROOT / record['path']).read_bytes())
            if sha256(target) != record['sha256']:
                raise ValueError('Source changed while taking snapshot: ' + record['path'])
            snapshots.append(record)
        wrapper = out / 'core_area.v'
        shutil.copyfile(DSE_ROOT / 'core_area.v', wrapper)
        shutil.copyfile(DSE_ROOT / 'ideal_clock.sdc', out / 'ideal_clock.sdc')
        shutil.copyfile(DSE_ROOT / 'synth_area.tcl', out / 'synth_area.tcl')
        shutil.copyfile(design['filelist'], out / 'rtl.f')
        # One compilation unit preserves the original project's shared macros.
        # SYNTHESIS removes simulation-only register delays from sys_defs.vh.
        unit = ['`define SYNTHESIS', verilog_include(out / 'inputs/sys_defs.vh')]
        unit.extend(verilog_include(out / 'inputs' / p.relative_to(LAB_ROOT))
                    for p in design['rtl_files'])
        unit.append(verilog_include(wrapper))
        (out / 'compilation_unit.sv').write_text('\n'.join(unit) + '\n', encoding='utf-8')
        write_json(out / 'library_manifest.json', library_manifest)
        if simulation:
            write_json(out / 'simulation_summary.json', simulation['data'])
            summary['mean_cpi'] = simulation['mean_cpi']
            summary['validation_fingerprint'] = simulation['data']['validation_fingerprint']
            summary['simulation_summary_sha256'] = simulation['sha256']
        config = [
            'set library_file ' + tcl_string(library),
            'set constraint_file ' + tcl_string(out / 'ideal_clock.sdc'),
            'set compilation_unit ' + tcl_string(out / 'compilation_unit.sv'),
            'set include_dirs ' + tcl_list(out / 'inputs' / p.relative_to(LAB_ROOT)
                                           for p in design['include_dirs']),
        ]
        (out / 'config.tcl').write_text('\n'.join(config) + '\n', encoding='utf-8')
        comparison = {
            'conditions': CONDITIONS,
            'constraint_sha256': sha256(out / 'ideal_clock.sdc'),
            'wrapper_sha256': sha256(wrapper),
            'synthesis_script_sha256': sha256(out / 'synth_area.tcl'),
            'library_sha256': sha256(library),
        }
        summary['comparison_fingerprint'] = object_hash(comparison)
        manifest = dict(comparison)
        manifest.update({'input_files': snapshots, 'rtl_fingerprint': design['rtl_fingerprint'],
                         'rtl_files': [p.relative_to(LAB_ROOT).as_posix()
                                       for p in design['rtl_files']],
                         'genus_executable': executable, 'created_utc': stamp,
                         'runner_sha256': sha256(Path(__file__)),
                         'comparison_fingerprint': summary['comparison_fingerprint'],
                         'simulation_summary': None if simulation is None else {
                             'path': simulation['path'], 'sha256': simulation['sha256'],
                             'validation_fingerprint': simulation['data']['validation_fingerprint']}})
        write_json(out / 'run_manifest.json', manifest)
        env = os.environ.copy()
        env['DSE_CONFIG'] = str(out / 'config.tcl')
        with (out / 'genus.log').open('w', encoding='utf-8') as log:
            proc = subprocess.run([executable, '-no_gui', '-files', str(out / 'synth_area.tcl')],
                                  cwd=str(out), env=env, stdout=log, stderr=subprocess.STDOUT)
        log_text = (out / 'genus.log').read_text(encoding='utf-8', errors='replace')
        if proc.returncode or not re.search(r'^DSE_AREA_DONE\s*$', log_text, re.M):
            raise ValueError('Genus did not finish successfully; inspect genus.log')
        if re.search(r'^\s*(?:Error|ERROR|Fatal|FATAL)(?:\s|:)', log_text, re.M):
            raise ValueError('Genus reported an error; inspect genus.log')
        for name in ['area.rpt', 'gates.rpt', 'timing.rpt', 'mapped.v', 'mapped.sdc',
                     'check_design.rpt', 'check_design_mapped.rpt']:
            if not (out / name).is_file() or not (out / name).stat().st_size:
                raise ValueError('Missing report: ' + name)
        for name in ['check_design.rpt', 'check_design_mapped.rpt']:
            if 'No unresolved references' not in (out / name).read_text(errors='replace'):
                raise ValueError('Unresolved reference check failed: ' + name)
        metrics = parse_reports((out / 'area.rpt').read_text(), (out / 'timing.rpt').read_text())
        summary.update(metrics)
        if metrics['cell_count'] <= 0 or metrics['cell_area_um2'] <= 0:
            summary['status'] = 'empty_design'
            raise ValueError('No mapped hardware: implement the six RTL modules before DSE')
        if metrics['timing_met'] is None:
            raise ValueError('No timed path found; inspect the design and clock constraints')
        summary['status'] = 'ok' if metrics['timing_met'] else 'timing_violation'
        if simulation is None:
            summary['eligibility_reasons'].append('full_56_case_result_not_attached')
        if not metrics['timing_met']:
            summary['eligibility_reasons'].append('timing_target_not_met')
        summary['eligible'] = not summary['eligibility_reasons']
        summary_files(out, summary)
        print('Cell Area: {:.3f} um^2; cells: {}; worst slack: {:.3f} ns; timing: {}'.format(
            metrics['cell_area_um2'], metrics['cell_count'], metrics['worst_slack_ns'],
            'MET' if metrics['timing_met'] else 'VIOLATED'))
        print('Mean CPI: {}; eligible: {}'.format(
            'not attached' if summary['mean_cpi'] is None else '{:.9f}'.format(summary['mean_cpi']),
            summary['eligible']))
        print('Summary: ' + str(out / 'summary.json'))
        return 0
    except (OSError, ValueError, RuntimeError) as error:
        summary['error'] = str(error)
        summary_files(out, summary)
        raise ValueError(str(error) + '\nReports: ' + str(out))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--liberty', default=str(PDK_ROOT / 'timing/typical.lib'))
    parser.add_argument('--lef', default=str(PDK_ROOT / 'gsclib045.lef'))
    commands = parser.add_subparsers(dest='command')
    commands.add_parser('prepare-lib', help='prepare or validate the reusable aiarch_lab2_1 library')
    run = commands.add_parser('run', help='measure one CPU implementation')
    run.add_argument('--name', default='baseline')
    run.add_argument('--sim-summary', help='successful full-suite simulation summary.json')
    run.add_argument('--rtl-filelist', default='dse/rtl.f')
    run.add_argument('--genus', default='genus')
    args = parser.parse_args()
    try:
        if args.command == 'prepare-lib':
            path, manifest, reused = prepare_library(Path(args.liberty), Path(args.lef), BUILD_ROOT / 'lib')
            print(('Reusing' if reused else 'Prepared') + ' library: ' + str(path))
            print('Library cells: ' + str(manifest['cell_count']))
            return 0
        if args.command == 'run':
            return run_area(args)
        parser.print_help()
        return 2
    except (OSError, ValueError, RuntimeError) as error:
        print('DSE failed: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
