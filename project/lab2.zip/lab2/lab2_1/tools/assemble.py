#!/usr/bin/env python3
"""Assemble Alpha test sources with the original course assembler on xLab."""

import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile


LAB_ROOT = Path(__file__).resolve().parents[1]
ASSEMBLER_ROOT = Path(__file__).resolve().parent / 'assembler'


def assemble(source, output):
    source = source.resolve()
    if not source.is_file() or source.suffix != '.s':
        raise ValueError('Expected an assembly source file: ' + str(source))
    perl = shutil.which('perl')
    if not perl:
        raise ValueError('Cannot find Perl; run this tool in the course xLab Linux terminal')
    # Work on executable temporary copies; extraction from a zip need not
    # preserve the Linux executable permission on the bundled binaries.
    with tempfile.TemporaryDirectory(prefix='lab2_1_assemble_') as temporary:
        work = Path(temporary)
        for name in ['gas-alpha', 'objdump-alpha', 'vs-asm']:
            original = ASSEMBLER_ROOT / name
            if not original.is_file():
                raise ValueError('Missing course assembler file: ' + str(original))
            target = work / name
            shutil.copyfile(str(original), str(target))
            target.chmod(0o700)
        result = subprocess.run([perl, str(work / 'vs-asm'), str(source)],
                                cwd=str(work), stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=30)
    log_dir = LAB_ROOT / 'build' / 'assembly'
    log_dir.mkdir(parents=True, exist_ok=True)
    log = log_dir / (source.stem + '.log')
    log.write_bytes(result.stderr)
    try:
        lines = result.stdout.decode('ascii').splitlines()
    except UnicodeDecodeError:
        lines = []
    if (result.returncode or not lines or
            any(not re.fullmatch(r'[0-9a-fA-F]{16}', line) for line in lines)):
        raise ValueError('Assembly failed or produced an invalid memory image; inspect ' + str(log))
    if len(lines) > 8192:
        raise ValueError('Memory image exceeds the fixed 64 KiB memory: ' + str(source))
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(('\n'.join(lines) + '\n').encode('ascii'))
    print('Assembled {} -> {} ({} words)'.format(source.name, output, len(lines)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', nargs='*', help='sources; default: all public test_progs/*.s')
    parser.add_argument('--output', type=Path, help='output image for one source')
    args = parser.parse_args()
    sources = [Path(p) for p in args.source] if args.source else sorted((LAB_ROOT / 'test_progs').glob('*.s'))
    if args.output and len(sources) != 1:
        parser.error('--output requires exactly one source')
    try:
        if os.name != 'posix':
            raise ValueError('The bundled assembler runs on Linux; use the xLab terminal')
        for source in sources:
            assemble(source, args.output if args.output else source.with_suffix('.mem'))
        return 0
    except (OSError, ValueError, subprocess.TimeoutExpired) as error:
        print('Assembly failed: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
